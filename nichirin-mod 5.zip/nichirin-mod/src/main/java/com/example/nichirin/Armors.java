package com.example.nichirin;

import net.minecraft.item.Item;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.Map;

/** Trang phuc mac duoc: Dong Phuc Sat Quy, Trang Phuc Quy, va 16 ao Haori theo hoi tho. */
public class Armors {
    private static final TagKey<Item> REPAIR = TagKey.of(RegistryKeys.ITEM, Identifier.of(Nichirin.ID, "repairs_outfit"));

    private static ArmorMaterial mat(String asset, int durability, int h, int c, int l, int b, float toughness) {
        RegistryKey<EquipmentAsset> key = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, Identifier.of(Nichirin.ID, asset));
        return new ArmorMaterial(durability,
                Map.of(EquipmentType.HELMET, h, EquipmentType.CHESTPLATE, c, EquipmentType.LEGGINGS, l, EquipmentType.BOOTS, b),
                15, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, toughness, 0.0f, REPAIR, key);
    }

    private static void reg(String id, ArmorMaterial m, EquipmentType t, Rarity r) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(Nichirin.ID, id));
        Item it = Registry.register(Registries.ITEM, key.getValue(), new Item(new Item.Settings().registryKey(key).armor(m, t).rarity(r)));
        Nichirin.EXTRAS.add(it);
    }

    public static void register() {
        ArmorMaterial slayer = mat("slayer", 25, 2, 6, 5, 2, 1.0f);
        reg("slayer_helmet", slayer, EquipmentType.HELMET, Rarity.UNCOMMON);
        reg("slayer_chestplate", slayer, EquipmentType.CHESTPLATE, Rarity.UNCOMMON);
        reg("slayer_leggings", slayer, EquipmentType.LEGGINGS, Rarity.UNCOMMON);
        reg("slayer_boots", slayer, EquipmentType.BOOTS, Rarity.UNCOMMON);

        ArmorMaterial demon = mat("demon", 37, 3, 8, 6, 3, 2.0f);
        reg("demon_helmet", demon, EquipmentType.HELMET, Rarity.RARE);
        reg("demon_chestplate", demon, EquipmentType.CHESTPLATE, Rarity.RARE);
        reg("demon_leggings", demon, EquipmentType.LEGGINGS, Rarity.RARE);
        reg("demon_boots", demon, EquipmentType.BOOTS, Rarity.RARE);

        for (Breath b : Breath.values()) {
            String name = "haori_" + b.name().toLowerCase();
            reg(name, mat(name, 30, 0, 6, 0, 0, 1.0f), EquipmentType.CHESTPLATE, Rarity.EPIC);
        }
    }
}
