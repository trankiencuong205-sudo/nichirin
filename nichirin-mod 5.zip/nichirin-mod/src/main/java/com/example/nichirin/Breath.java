package com.example.nichirin;

import net.minecraft.util.Formatting;

public enum Breath {
    SUN("sun_blade", "Hơi Thở Mặt Trời", "Hơi thở gốc, rực cháy như mặt trời", Formatting.GOLD),
    MOON("moon_blade", "Hơi Thở Mặt Trăng", "Lưỡi chém trăng khuyết xuyên thấu", Formatting.BLUE),
    WATER("water_blade", "Hơi Thở Nước", "Chém uyển chuyển như dòng nước", Formatting.AQUA),
    FIRE("fire_blade", "Hơi Thở Lửa", "Chém bằng ngọn lửa rực cháy", Formatting.RED),
    THUNDER("thunder_blade", "Hơi Thở Sấm Sét", "Tốc độ như chớp giật", Formatting.YELLOW),
    WIND("wind_blade", "Hơi Thở Gió", "Lốc xoáy cắt xé mọi thứ", Formatting.GREEN),
    STONE("stone_blade", "Hơi Thở Đá", "Nặng nề, chậm nhưng cực mạnh", Formatting.DARK_GRAY),
    MIST("mist_blade", "Hơi Thở Sương Mù", "Sương mù làm quỷ mất phương hướng", Formatting.GRAY),
    SOUND("sound_blade", "Hơi Thở Âm Thanh", "Sóng âm nổ làm quỷ choáng váng", Formatting.GOLD),
    LOVE("love_blade", "Hơi Thở Tình Yêu", "Chém mềm dẻo, hồi máu", Formatting.DARK_PURPLE),
    SERPENT("serpent_blade", "Hơi Thở Rắn", "Nhát chém uốn lượn kèm độc", Formatting.DARK_AQUA),
    FLOWER("flower_blade", "Hơi Thở Hoa", "Nhiều nhát chém liên tiếp như cánh hoa", Formatting.LIGHT_PURPLE),
    INSECT("insect_blade", "Hơi Thở Côn Trùng", "Đâm xuyên kèm chất độc", Formatting.DARK_PURPLE),
    BEAST("beast_blade", "Hơi Thở Thú", "Chém hoang dã, nhanh và dữ", Formatting.DARK_GREEN),
    CLOUD("cloud_blade", "Hơi Thở Mây (Custom)", "Mây cuộn bao phủ, chém lướt như mây trôi", Formatting.WHITE),
    ICE("ice_blade", "Hơi Thở Băng (Custom)", "Chém băng giá làm quỷ đóng băng", Formatting.AQUA);

    public final String id, title, desc;
    public final Formatting color;

    Breath(String id, String title, String desc, Formatting color) {
        this.id = id; this.title = title; this.desc = desc; this.color = color;
    }
}
