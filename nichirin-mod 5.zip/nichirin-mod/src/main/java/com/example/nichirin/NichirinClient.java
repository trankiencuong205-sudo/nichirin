package com.example.nichirin;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class NichirinClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(Nichirin.ID, "main"));
    private static KeyBinding menu;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) -> ClientData.parse(payload.data()));
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.nichirin.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));
        HudElementRegistry.addLast(Identifier.of(Nichirin.ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            int w = 100, h = 7, x = sw / 2 - 91, y = sh - 52;
            float frac = Math.max(0f, Math.min(1f, ClientData.energy / (float) Math.max(1, ClientData.maxEnergy)));
            ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
            ctx.fill(x, y, x + w, y + h, 0xFF1A2230);
            ctx.fill(x, y, x + (int) (w * frac), y + h, ClientData.demonRank >= 0 ? Demon.RANK_COLOR[Math.min(ClientData.demonRank, 3)] | 0xFF000000 : 0xFF3AA0FF);
            ctx.fill(x, y, x + (int) (w * frac), y + 2, 0x55FFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer, ClientData.energy + "/" + ClientData.maxEnergy, x + w + 4, y, 0xFFFFFFFF);
            if (ClientData.demonRank >= 0) {
                int hy = y - 10;
                float hf = Math.max(0f, Math.min(1f, ClientData.demonHunger / 100f));
                ctx.fill(x - 1, hy - 1, x + w + 1, hy + 5, 0xFF000000);
                ctx.fill(x, hy, x + w, hy + 4, 0xFF2A0A0A);
                ctx.fill(x, hy, x + (int) (w * hf), hy + 4, 0xFFC01830);
                ctx.drawTextWithShadow(mc.textRenderer, Demon.RANK_NAMES[Math.min(ClientData.demonRank, 3)] + "  XP " + ClientData.demonXp, x + w + 4, hy - 2, 0xFFFF8080);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menu.wasPressed()) {
                if (client.player == null) continue;
                ClientPlayNetworking.send(new ActionPayload(2, 0, 0));
                client.setScreen(new BreathScreen());
            }
        });
    }
}
