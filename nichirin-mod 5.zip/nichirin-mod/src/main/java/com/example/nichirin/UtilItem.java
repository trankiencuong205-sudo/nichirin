package com.example.nichirin;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class UtilItem extends Item {
    public enum Kind { WISTERIA, LILY, MARK, FOCUS, SUMMON, UPPER, DEMON_CHOSEN, ALLY, CURE }
    private final Kind kind;

    public UtilItem(Settings s, Kind k) { super(s); this.kind = k; }

    private static void snd(ServerWorld w, PlayerEntity p, SoundEvent s, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, 1.0f, pitch);
    }

    private static void msg(PlayerEntity p, String t, Formatting f) { p.sendMessage(Text.literal(t).formatted(f), true); }

    @Override
    public ActionResult use(World world, PlayerEntity p, Hand hand) {
        p.swingHand(hand);
        if (!(world instanceof ServerWorld w)) return ActionResult.SUCCESS;
        boolean used = true;
        switch (kind) {
            case WISTERIA -> {
                snd(w, p, SoundEvents.ENTITY_SPLASH_POTION_BREAK, 0.8f);
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                for (int i = 0; i < 80; i++) w.spawnParticles(ParticleTypes.WITCH, c.x, c.y, c.z, 1, 4, 1, 4, 0.05);
                for (LivingEntity t : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(8, 3, 8), e -> e != p && e.isAlive() && e instanceof Monster)) {
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 200, 2));
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
                    t.damage(w, w.getDamageSources().magic(), 8.0f);
                }
                p.getItemCooldownManager().set(p.getStackInHand(hand), 100);
            }
            case LILY -> {
                if (!Demon.isDemon(p.getUuid())) { msg(p, "Chi quy moi dung duoc hoa Bi Ngan Xanh!", Formatting.RED); return ActionResult.FAIL; }
                Demon.sunImmune(p.getUuid());
                msg(p, "Ban da vuot qua duoc anh nang!", Formatting.AQUA);
                snd(w, p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2f);
            }
            case MARK -> {
                effects(p, 3600, StatusEffects.STRENGTH, 2, StatusEffects.SPEED, 1, StatusEffects.RESISTANCE, 1, StatusEffects.HEALTH_BOOST, 3);
                msg(p, "Dau An Sat Quy da xuat hien!", Formatting.RED);
                snd(w, p, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.8f);
            }
            case FOCUS -> {
                effects(p, 6000, StatusEffects.SPEED, 1, StatusEffects.HASTE, 2, StatusEffects.REGENERATION, 0, StatusEffects.JUMP_BOOST, 1);
                msg(p, "Toan Tap Trung Thuong Truc!", Formatting.AQUA);
                snd(w, p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.5f);
            }
            case SUMMON -> spawn(w, p, EntityType.ZOMBIE, "Quy", 50, 7, 0.3, Formatting.RED);
            case CURE -> {
                if (!(p instanceof net.minecraft.server.network.ServerPlayerEntity sp) || !Demon.cure(sp)) {
                    msg(p, Config.allowCure ? "Bạn không phải quỷ." : "Máy chủ đã tắt thuốc giải quỷ.", Formatting.RED);
                    return ActionResult.FAIL;
                }
                snd(w, p, SoundEvents.ENTITY_ZOMBIE_VILLAGER_CURE, 1.0f);
            }
            case DEMON_CHOSEN -> Mobs.spawnDemon(w, p, PlayerData.chosenDemon(p.getUuid()));
            case ALLY -> Mobs.spawnAlly(w, p, PlayerData.chosen(p.getUuid()));
            case UPPER -> spawn(w, p, EntityType.WITHER_SKELETON, "Thuong Huyen Quy", 200, 14, 0.36, Formatting.DARK_RED);
        }
        if (used && !p.isCreative()) p.getStackInHand(hand).decrement(1);
        return ActionResult.SUCCESS;
    }

    private static void effects(PlayerEntity p, int ticks, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> a, int aa,
                                net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> b, int ba,
                                net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> c, int ca,
                                net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> d, int da) {
        p.addStatusEffect(new StatusEffectInstance(a, ticks, aa));
        p.addStatusEffect(new StatusEffectInstance(b, ticks, ba));
        p.addStatusEffect(new StatusEffectInstance(c, ticks, ca));
        p.addStatusEffect(new StatusEffectInstance(d, ticks, da));
    }

    private static void spawn(ServerWorld w, PlayerEntity p, EntityType<? extends MobEntity> type, String name, double hp, double dmg, double speed, Formatting col) {
        MobEntity m = type.create(w, SpawnReason.TRIGGERED);
        if (m == null) return;
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        look = look.lengthSquared() > 1.0E-4 ? look.normalize().multiply(3) : new Vec3d(3, 0, 0);
        m.setPosition(p.getX() + look.x, p.getY(), p.getZ() + look.z);
        if (m.getAttributeInstance(EntityAttributes.MAX_HEALTH) != null) m.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(hp);
        if (m.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE) != null) m.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(dmg);
        if (m.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED) != null) m.getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(speed);
        m.setHealth((float) hp);
        m.setCustomName(Text.literal(name).formatted(col, Formatting.BOLD));
        m.setCustomNameVisible(true);
        m.setPersistent();
        m.addCommandTag(Nichirin.DEMON_TAG);
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1000000, 2, false, false));
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 1000000, 0, false, false));
        w.spawnEntity(m);
        snd(w, p, SoundEvents.ENTITY_WITHER_SPAWN, 1.5f);
    }
}
