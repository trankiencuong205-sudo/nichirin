package com.example.nichirin;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

/**
 * Che do quy VINH VIEN. Luu theo UUID nguoi choi (config/nichirin-demons.properties), nen ton tai qua chet,
 * thoat game, khoi dong lai va doi chieu. Chi may chu thay doi trang thai (an toan khi choi multiplayer).
 */
public class Demon {
    public static final String[] RANK_NAMES = {"Quỷ Thường", "Hạ Huyền", "Thượng Huyền", "Thượng Huyền Nhất"};
    public static final int[] RANK_XP = {0, 200, 800, 2500};
    public static final int[] RANK_COLOR = {0xB02030, 0x8A30C0, 0x3030D0, 0xFFD020};

    public static class State {
        public int rank = 0, xp = 0;
        public float hunger = 100f;
        public boolean sunImmune = false;
    }

    private static final Map<UUID, State> DEMONS = new HashMap<>();

    public static boolean isDemon(UUID id) { return DEMONS.containsKey(id); }
    public static State get(UUID id) { return DEMONS.get(id); }
    public static void sunImmune(UUID id) { State s = DEMONS.get(id); if (s != null) { s.sunImmune = true; save(); } }

    public static void become(ServerPlayerEntity p) {
        State s = new State();
        DEMONS.put(p.getUuid(), s);
        save();
        p.sendMessage(Text.literal("Bạn đã trở thành quỷ vĩnh viễn! Hãy săn máu để tiến hóa.").formatted(Formatting.DARK_RED, Formatting.BOLD), true);
        PlayerData.sync(p);
    }

    public static boolean cure(ServerPlayerEntity p) {
        if (!Config.allowCure) return false;
        if (DEMONS.remove(p.getUuid()) == null) return false;
        save();
        p.sendMessage(Text.literal("Bạn đã trở lại làm người.").formatted(Formatting.GREEN, Formatting.BOLD), true);
        PlayerData.sync(p);
        return true;
    }

    public static void feed(ServerPlayerEntity p, float amount, int xp) {
        State s = DEMONS.get(p.getUuid());
        if (s == null) return;
        s.hunger = Math.min(100f, s.hunger + amount);
        s.xp += xp;
        while (s.rank < RANK_NAMES.length - 1 && s.xp >= RANK_XP[s.rank + 1]) {
            s.rank++;
            p.sendMessage(Text.literal("Tiến hóa: " + RANK_NAMES[s.rank] + "!").formatted(Formatting.GOLD, Formatting.BOLD), true);
        }
        PlayerData.sync(p);
    }

    /** "rank,hunger,xp,sunImmune" hoac "-" neu la nguoi */
    public static String syncString(UUID id) {
        State s = DEMONS.get(id);
        if (s == null) return "dem=-;";
        return "dem=" + s.rank + "," + (int) s.hunger + "," + s.xp + "," + (s.sunImmune ? 1 : 0) + ";";
    }

    // ---- luu tru ----
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nichirin-demons.properties"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) { p.load(in); }
            for (String k : p.stringPropertyNames()) {
                try {
                    String[] a = p.getProperty(k).split("\\|");
                    State s = new State();
                    s.rank = Integer.parseInt(a[0]); s.xp = Integer.parseInt(a[1]);
                    s.hunger = Float.parseFloat(a[2]); s.sunImmune = Boolean.parseBoolean(a[3]);
                    DEMONS.put(UUID.fromString(k), s);
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            DEMONS.forEach((k, s) -> p.setProperty(k.toString(), s.rank + "|" + s.xp + "|" + s.hunger + "|" + s.sunImmune));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Nichirin permanent demons"); }
        } catch (Exception ignored) { }
    }

    public static void register() {
        load();
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> save());

        // san moi: giet quai / dong vat -> het doi, len cap
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            Entity a = source.getAttacker();
            if (!(a instanceof ServerPlayerEntity sp) || !isDemon(sp.getUuid())) return;
            if (entity instanceof Monster) feed(sp, 25f, 10);
            else if (entity instanceof AnimalEntity) feed(sp, 12f, 2);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();
            if (t % 10 != 0 || DEMONS.isEmpty()) return;
            for (ServerWorld w : server.getWorlds()) {
                for (ServerPlayerEntity p : w.getPlayers()) {
                    State s = DEMONS.get(p.getUuid());
                    if (s == null || !p.isAlive()) continue;
                    int r = s.rank;
                    // suc manh theo cap bac (ap lai lien tuc nen khong mat khi chet)
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, r >= 2 ? 2 : 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, r >= 3 ? 2 : 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, r >= 2 ? 2 : 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, r >= 3 ? 1 : 0, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 260, 0, false, false));

                    // khat mau
                    if (Config.hunger) {
                        s.hunger = Math.max(0f, s.hunger - 0.0417f);
                        if (s.hunger < 20f) {
                            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 1, false, false));
                            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0, false, false));
                        }
                        if (s.hunger <= 0f && t % 40 == 0) p.damage(w, w.getDamageSources().magic(), 2.0f);
                        if (s.hunger < 20f && t % 100 == 0) p.sendMessage(Text.literal("Bạn khát máu! Hãy săn quái.").formatted(Formatting.DARK_RED), true);
                    }

                    // hao quang + mat do
                    Vec3d e = p.getEyePos(), look = p.getRotationVec(1.0f);
                    Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
                    if (right.lengthSquared() > 1.0E-4) {
                        right = right.normalize();
                        for (int k = -1; k <= 1; k += 2) {
                            Vec3d eye = e.add(look.multiply(0.28)).add(right.multiply(0.15 * k));
                            w.spawnParticles(new DustParticleEffect(RANK_COLOR[r], 0.6f), eye.x, eye.y, eye.z, 1, 0.0, 0.0, 0.0, 0.0);
                        }
                    }
                    w.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.getX(), p.getY() + 1, p.getZ(), 4 + r * 3, 0.4, 0.8, 0.4, 0.02);
                    if (r >= 1) w.spawnParticles(new DustParticleEffect(RANK_COLOR[r], 1.2f), p.getX(), p.getY() + 1, p.getZ(), 6 + r * 4, 0.5, 0.9, 0.5, 0.0);
                    if (r >= 2) w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 0.2, p.getZ(), 3, 0.4, 0.1, 0.4, 0.01);
                    if (r >= 3) w.spawnParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 2.3, p.getZ(), 2, 0.3, 0.1, 0.3, 0.01);

                    // anh nang
                    if (!s.sunImmune && w.isDay() && !w.isRaining() && w.isSkyVisible(p.getBlockPos())) {
                        p.setFireTicks(60);
                        p.sendMessage(Text.literal("Ánh nắng đang thiêu đốt bạn!").formatted(Formatting.GOLD), true);
                    }
                }
            }
            if (t % 600 == 0) save();
        });
    }
}
