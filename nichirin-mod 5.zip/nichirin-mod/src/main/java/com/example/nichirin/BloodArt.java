package com.example.nichirin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/** Huyet Quy Thuat - chi dung khi da hoa quy. Chon quy + ky nang trong menu (phim K), hoac Shift+chuot phai de doi ky nang. */
public class BloodArt extends Item {
    public BloodArt(Settings s) { super(s); }

    @Override
    public ActionResult use(World world, PlayerEntity p, Hand hand) {
        p.swingHand(hand);
        if (!(world instanceof ServerWorld w) || !(p instanceof ServerPlayerEntity sp)) return ActionResult.SUCCESS;
        UUID id = p.getUuid();
        if (!Demon.isDemon(id)) {
            p.sendMessage(Text.literal("Bạn phải hóa quỷ (uống Máu Quỷ) mới dùng được!").formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        DemonType d = PlayerData.chosenDemon(id);
        List<DemonArts.Art> list = DemonArts.of(d);
        int idx = PlayerData.selectedArt(id, d);
        if (p.isSneaking()) {
            idx = (idx + 1) % list.size();
            PlayerData.selectArt(id, d, idx);
            DemonArts.Art a = list.get(idx);
            p.sendMessage(Text.literal(d.title + ": " + a.name() + (a.canon() ? "" : " [Custom Skill]")).formatted(d.color, Formatting.BOLD), true);
            PlayerData.sync(sp);
            return ActionResult.SUCCESS;
        }
        DemonArts.Art a = list.get(idx);
        String key = "A." + d.name() + "." + a.num();
        int cost = Config.cost(key, a.energy());
        if (!p.isCreative() && PlayerData.energy(id) < cost) {
            p.sendMessage(Text.literal("Không đủ năng lượng! Cần " + cost + ", có " + (int) PlayerData.energy(id)).formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        DemonSkills.run(w, p, a, 1.0 + 0.15 * PlayerData.levelArt(id, d, idx));
        if (!p.isCreative()) PlayerData.setEnergy(id, PlayerData.energy(id) - cost);
        int cd = Config.cooldown(key, a.cooldown());
        if (cd > 0) p.getItemCooldownManager().set(p.getStackInHand(hand), cd);
        p.sendMessage(Text.literal(a.name() + "  (NL " + (int) PlayerData.energy(id) + "/" + PlayerData.maxEnergy(id) + ")").formatted(d.color), true);
        PlayerData.sync(sp);
        return ActionResult.SUCCESS;
    }
}
