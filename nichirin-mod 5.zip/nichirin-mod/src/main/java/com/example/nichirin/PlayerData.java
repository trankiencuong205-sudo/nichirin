package com.example.nichirin;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

/** Du lieu nguoi choi: nang luong, hoi tho dang chon, thuc dang chon, cap nang cap. Luu vao config/nichirin-players.properties */
public class PlayerData {
    public static final int MAX_LEVEL = 5;

    private static final Map<UUID, Float> ENERGY = new HashMap<>();
    private static final Map<String, Integer> LEVELS = new HashMap<>();   // uuid|breath|idx
    private static final Map<String, Integer> SELECTED = new HashMap<>(); // uuid|breath
    private static final Map<UUID, Integer> CHOSEN = new HashMap<>();     // uuid -> breath ordinal
    private static final Map<UUID, Integer> CHOSEN_DEMON = new HashMap<>();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nichirin-players.properties"); }

    // ---- getters / setters ----
    public static int maxEnergy(UUID id) {
        Demon.State d = Demon.get(id);
        return Config.maxEnergy + (d != null ? 25 * d.rank : 0);
    }
    public static float energy(UUID id) { return ENERGY.getOrDefault(id, (float) maxEnergy(id)); }
    public static void setEnergy(UUID id, float v) { ENERGY.put(id, Math.max(0, Math.min(maxEnergy(id), v))); }

    public static int level(UUID id, Breath b, int idx) { return LEVELS.getOrDefault(id + "|" + b.ordinal() + "|" + idx, 0); }
    public static void setLevel(UUID id, Breath b, int idx, int lv) { LEVELS.put(id + "|" + b.ordinal() + "|" + idx, lv); save(); }

    public static int selected(UUID id, Breath b) {
        int n = Techniques.of(b).size();
        int s = SELECTED.getOrDefault(id + "|" + b.ordinal(), 0);
        return s >= 0 && s < n ? s : 0;
    }
    public static void select(UUID id, Breath b, int idx) { SELECTED.put(id + "|" + b.ordinal(), idx); save(); }

    public static Breath chosen(UUID id) {
        Breath[] all = Breath.values();
        int o = CHOSEN.getOrDefault(id, 0);
        return all[o >= 0 && o < all.length ? o : 0];
    }
    public static void choose(UUID id, Breath b) { CHOSEN.put(id, b.ordinal()); save(); }

    // ---- Huyet Quy Thuat ----
    public static int levelArt(UUID id, DemonType d, int idx) { return LEVELS.getOrDefault(id + "|d" + d.ordinal() + "|" + idx, 0); }
    public static void setLevelArt(UUID id, DemonType d, int idx, int lv) { LEVELS.put(id + "|d" + d.ordinal() + "|" + idx, lv); save(); }
    public static int selectedArt(UUID id, DemonType d) {
        int n = DemonArts.of(d).size();
        int s = SELECTED.getOrDefault(id + "|d" + d.ordinal(), 0);
        return s >= 0 && s < n ? s : 0;
    }
    public static void selectArt(UUID id, DemonType d, int idx) { SELECTED.put(id + "|d" + d.ordinal(), idx); save(); }
    public static DemonType chosenDemon(UUID id) {
        DemonType[] all = DemonType.values();
        int o = CHOSEN_DEMON.getOrDefault(id, 0);
        return all[o >= 0 && o < all.length ? o : 0];
    }
    public static void chooseDemon(UUID id, DemonType d) { CHOSEN_DEMON.put(id, d.ordinal()); save(); }

    // ---- sync string -> client ----
    public static String syncString(UUID id) {
        StringBuilder sb = new StringBuilder();
        sb.append("br=").append(chosen(id).ordinal()).append(';');
        sb.append("e=").append((int) energy(id)).append(';');
        sb.append("mx=").append(maxEnergy(id)).append(';');
        sb.append(Config.sync()).append(';');
        sb.append(Demon.syncString(id));
        sb.append("sel=");
        for (Breath b : Breath.values()) sb.append(b.ordinal()).append(':').append(selected(id, b)).append(',');
        sb.append(";dm=").append(chosenDemon(id).ordinal()).append(";dsel=");
        for (DemonType d : DemonType.values()) sb.append(d.ordinal()).append(':').append(selectedArt(id, d)).append(',');
        sb.append(";dlvl=");
        for (DemonType d : DemonType.values()) {
            int n = DemonArts.of(d).size();
            for (int i = 0; i < n; i++) {
                int l = levelArt(id, d, i);
                if (l > 0) sb.append(d.ordinal()).append('.').append(i).append(':').append(l).append(',');
            }
        }
        sb.append(";lvl=");
        for (Breath b : Breath.values()) {
            int n = Techniques.of(b).size();
            for (int i = 0; i < n; i++) {
                int l = level(id, b, i);
                if (l > 0) sb.append(b.ordinal()).append('.').append(i).append(':').append(l).append(',');
            }
        }
        return sb.toString();
    }

    public static void sync(ServerPlayerEntity p) {
        ServerPlayNetworking.send(p, new SyncPayload(syncString(p.getUuid())));
    }

    // ---- persistence ----
    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties pr = new Properties();
            try (InputStream in = Files.newInputStream(f)) { pr.load(in); }
            for (String k : pr.stringPropertyNames()) {
                String v = pr.getProperty(k);
                try {
                    if (k.startsWith("lvl.")) LEVELS.put(k.substring(4), Integer.parseInt(v));
                    else if (k.startsWith("sel.")) SELECTED.put(k.substring(4), Integer.parseInt(v));
                    else if (k.startsWith("br.")) CHOSEN.put(UUID.fromString(k.substring(3)), Integer.parseInt(v));
                    else if (k.startsWith("dm.")) CHOSEN_DEMON.put(UUID.fromString(k.substring(3)), Integer.parseInt(v));
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Properties pr = new Properties();
            LEVELS.forEach((k, v) -> pr.setProperty("lvl." + k, String.valueOf(v)));
            SELECTED.forEach((k, v) -> pr.setProperty("sel." + k, String.valueOf(v)));
            CHOSEN.forEach((k, v) -> pr.setProperty("br." + k, String.valueOf(v)));
            CHOSEN_DEMON.forEach((k, v) -> pr.setProperty("dm." + k, String.valueOf(v)));
            try (OutputStream out = Files.newOutputStream(file())) { pr.store(out, "Nichirin player data"); }
        } catch (Exception ignored) { }
    }

    public static void register() {
        Config.load();
        load();
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();
            if (t % 10 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                setEnergy(p.getUuid(), energy(p.getUuid()) + (float) (Config.regen * 0.5));
                if (t % 40 == 0) sync(p);
            }
        });
    }
}
