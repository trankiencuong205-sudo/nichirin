package com.example.nichirin;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Menu (phim K): chon Hoi Tho / Quy, chon thuc / ky nang, nang cap bang cap kinh nghiem. */
public class BreathScreen extends Screen {
    private int mode = 0;        // 0 = Hoi Tho, 1 = Huyet Quy Thuat
    private int view = 0;        // hoi tho / quy dang xem
    private int leftPage = 0, rightPage = 0;

    public BreathScreen() {
        super(Text.literal("Menu Diệt Quỷ"));
        view = ClientData.chosenBreath;
    }

    @Override
    protected void init() {
        ClientData.listener = this::clearAndInit;
        addDrawableChild(ButtonWidget.builder(Text.literal("Hơi Thở"), b -> { mode = 0; view = ClientData.chosenBreath; leftPage = 0; rightPage = 0; clearAndInit(); })
                .dimensions(10, 8, 90, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Huyết Quỷ Thuật"), b -> { mode = 1; view = ClientData.chosenDemon; leftPage = 0; rightPage = 0; clearAndInit(); })
                .dimensions(104, 8, 110, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Cài đặt"), b -> client.setScreen(new SettingsScreen()))
                .dimensions(218, 8, 70, 18).build());

        int count = mode == 0 ? Breath.values().length : DemonType.values().length;
        int rows = Math.max(4, (height - 90) / 20);
        // danh sach ben trai
        int start = leftPage * rows;
        for (int r = 0; r < rows && start + r < count; r++) {
            final int i = start + r;
            String name = mode == 0 ? Breath.values()[i].title : DemonType.values()[i].title;
            boolean cur = i == view;
            addDrawableChild(ButtonWidget.builder(Text.literal((cur ? "> " : "") + name), b -> { view = i; rightPage = 0; clearAndInit(); })
                    .dimensions(10, 34 + r * 20, 200, 18).build());
        }
        int ny = 34 + rows * 20 + 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Trước"), b -> { if (leftPage > 0) { leftPage--; clearAndInit(); } })
                .dimensions(10, ny, 98, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Sau >"), b -> { if ((leftPage + 1) * rows < count) { leftPage++; clearAndInit(); } })
                .dimensions(112, ny, 98, 16).build());

        // ben phai: chon + danh sach thuc
        int x0 = 220;
        int w = Math.max(120, Math.min(width - x0 - 50, 300));
        boolean chosen = mode == 0 ? view == ClientData.chosenBreath : view == ClientData.chosenDemon;
        String chooseLabel = (chosen ? "Đang chọn: " : "Chọn ") + (mode == 0 ? "hơi thở này" : "quỷ này");
        addDrawableChild(ButtonWidget.builder(Text.literal(chooseLabel), b -> send(mode == 0 ? 3 : 6, view, 0))
                .dimensions(x0, 34, w + 28, 18).build());

        int size = mode == 0 ? Techniques.of(Breath.values()[view]).size() : DemonArts.of(DemonType.values()[view]).size();
        int rrows = Math.max(3, (height - 130) / 20);
        int rs = rightPage * rrows;
        for (int r = 0; r < rrows && rs + r < size; r++) {
            final int i = rs + r;
            String label;
            String tip;
            boolean sel;
            int lv;
            if (mode == 0) {
                Techniques.Tech t = Techniques.of(Breath.values()[view]).get(i);
                lv = ClientData.level(view, i);
                sel = ClientData.sel[view] == i;
                label = "Thức " + t.num() + ": " + t.vn() + (t.canon() ? "" : " [Custom]");
                tip = t.vn() + "\n" + t.en() + "\n" + (t.canon() ? "Kỹ năng nguyên tác" : "Custom Skill (mod tự sáng tạo)")
                        + "\nSát thương: " + String.format("%.1f", t.damage() * (1 + 0.15 * lv)) + "  Tầm: " + t.range()
                        + "\nHồi chiêu: " + (t.cooldown() / 20.0) + "s  Năng lượng: " + t.energy()
                        + "\nCấp " + lv + "/" + PlayerData.MAX_LEVEL + "  (nâng cấp: " + (3 + lv * 2) + " cấp kinh nghiệm)";
            } else {
                DemonArts.Art a = DemonArts.of(DemonType.values()[view]).get(i);
                lv = ClientData.levelDemon(view, i);
                sel = ClientData.dsel[view] == i;
                label = a.name() + (a.canon() ? "" : " [Custom]");
                tip = a.name() + "\n" + (a.canon() ? "Kỹ năng bám sát nguyên tác" : "Custom Skill / tên mô tả của mod (không phải tên chính thức)")
                        + "\nLoại: " + a.pattern()
                        + "\nSát thương: " + String.format("%.1f", a.damage() * (1 + 0.15 * lv)) + "  Tầm: " + a.range()
                        + "\nHồi chiêu: " + (a.cooldown() / 20.0) + "s  Năng lượng: " + a.energy()
                        + "\nCấp " + lv + "/" + PlayerData.MAX_LEVEL + "  (nâng cấp: " + (3 + lv * 2) + " cấp kinh nghiệm)";
            }
            addDrawableChild(ButtonWidget.builder(Text.literal((sel ? "> " : "") + label + "  Lv" + lv), b -> send(mode == 0 ? 0 : 4, view, i))
                    .dimensions(x0, 56 + r * 20, w, 18).tooltip(Tooltip.of(Text.literal(tip))).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> send(mode == 0 ? 1 : 5, view, i))
                    .dimensions(x0 + w + 4, 56 + r * 20, 24, 18).tooltip(Tooltip.of(Text.literal("Nâng cấp (tốn cấp kinh nghiệm)"))).build());
        }
        int ry = 56 + rrows * 20 + 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Trước"), b -> { if (rightPage > 0) { rightPage--; clearAndInit(); } })
                .dimensions(x0, ry, w / 2 - 2, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Sau >"), b -> { if ((rightPage + 1) * rrows < size) { rightPage++; clearAndInit(); } })
                .dimensions(x0 + w / 2 + 2, ry, w / 2 - 2, 16).build());
    }

    private void send(int action, int a, int b) {
        ClientPlayNetworking.send(new ActionPayload(action, a, b));
    }

    @Override
    public void removed() { ClientData.listener = null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Năng lượng: " + ClientData.energy + "/" + ClientData.maxEnergy).formatted(Formatting.AQUA), 300, 12, 0xFFFFFFFF);
        String info = mode == 0 ? Breath.values()[view].desc : DemonType.values()[view].tag;
        ctx.drawTextWithShadow(textRenderer, Text.literal(info).formatted(Formatting.GRAY), 220, height - 40, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Click: chọn thức  |  +: nâng cấp  |  Shift+chuột phải trên kiếm: đổi thức").formatted(Formatting.DARK_GRAY), 10, height - 14, 0xFFFFFFFF);
    }
}
