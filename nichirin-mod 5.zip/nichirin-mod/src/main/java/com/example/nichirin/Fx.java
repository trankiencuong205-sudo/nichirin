package com.example.nichirin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Hieu ung hat ve thanh hinh (vet chem trang khuyet, xoan oc, vong sang...) theo mau tung hoi tho. */
public class Fx {
    public static int color(Breath b) {
        return switch (b) {
            case FIRE -> 0xFF4A1A;
            case SUN -> 0xFFC832;
            case WATER -> 0x2F7FFF;
            case THUNDER -> 0xFFE12A;
            case WIND -> 0x5CE08A;
            case FLOWER -> 0xFF8FD0;
            case MIST -> 0xD8DCE8;
            case SERPENT -> 0x28B4B4;
            case SOUND -> 0xFF9A1E;
            case LOVE -> 0xFF4C8C;
            case BEAST -> 0x4C8A4C;
            case STONE -> 0x9A9AA6;
            case MOON -> 0x7A7AFF;
            case INSECT -> 0xB45AE6;
            case CLOUD -> 0xBFD8F0;
            case ICE -> 0x8FE8FF;
        };
    }

    private static ParticleEffect dust(Breath b, float size) { return new DustParticleEffect(color(b), size); }

    private static void put(ServerWorld w, ParticleEffect pe, Vec3d v) {
        w.spawnParticles(pe, v.x, v.y, v.z, 1, 0.02, 0.02, 0.02, 0.0);
    }

    /** Vet chem hinh trang khuyet truoc mat, nghieng goc tilt (do). */
    public static void crescent(ServerWorld w, PlayerEntity p, Breath b, double dist, double radius, double tiltDeg) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();
        double t = Math.toRadians(tiltDeg);
        Vec3d dir = right.multiply(Math.cos(t)).add(up.multiply(Math.sin(t)));
        Vec3d perp = up.multiply(Math.cos(t)).subtract(right.multiply(Math.sin(t)));
        Vec3d center = p.getEyePos().add(look.multiply(dist));
        for (int layer = 0; layer < 3; layer++) {
            float size = layer == 1 ? 1.6f : 1.0f;
            for (double s = -1; s <= 1.0001; s += 0.04) {
                double bend = (1 - s * s) * radius * 0.45;        // cong ra truoc
                double thick = (layer - 1) * 0.12 * (1 - Math.abs(s));
                Vec3d pt = center.add(dir.multiply(s * radius)).add(look.multiply(bend)).add(perp.multiply(thick));
                put(w, dust(b, size), pt);
                if (layer == 1 && Math.abs(s) < 0.1) w.spawnParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.02);
            }
        }
    }

    /** Xoan oc / loc xoay quanh nguoi. */
    public static void spiral(ServerWorld w, PlayerEntity p, Breath b, double radius, double height, int turns) {
        Vec3d c = p.getEntityPos();
        int n = turns * 36;
        for (int i = 0; i < n; i++) {
            double f = (double) i / n;
            double a = f * turns * Math.PI * 2;
            double r = radius * (0.35 + 0.65 * f);
            put(w, dust(b, 1.3f), c.add(Math.cos(a) * r, f * height, Math.sin(a) * r));
        }
    }

    public static void ring(ServerWorld w, PlayerEntity p, Breath b, double radius, double y) {
        Vec3d c = p.getEntityPos().add(0, y, 0);
        int n = (int) (radius * 14) + 12;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            put(w, dust(b, 1.2f), c.add(Math.cos(a) * radius, 0, Math.sin(a) * radius));
        }
    }

    /** Vet mo (afterimage) phia sau khi lao toi. */
    public static void trail(ServerWorld w, PlayerEntity p, Breath b, double length) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d base = p.getEntityPos().add(0, 1, 0);
        for (double d = 0; d < length; d += 0.25) {
            Vec3d c = base.add(look.multiply(d));
            put(w, dust(b, 1.5f), c);
            put(w, dust(b, 0.8f), c.add(0, 0.5, 0));
            put(w, dust(b, 0.8f), c.add(0, -0.5, 0));
        }
    }

    /** Vong sang (halo) phia sau dau - dac trung Mat Troi. */
    public static void halo(ServerWorld w, PlayerEntity p, Breath b, double radius) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();
        Vec3d c = p.getEyePos().add(look.multiply(2.5));
        for (int i = 0; i < 60; i++) {
            double a = i * Math.PI * 2 / 60;
            put(w, dust(b, 1.6f), c.add(right.multiply(Math.cos(a) * radius)).add(up.multiply(Math.sin(a) * radius)));
        }
    }

    /** Tia set ngoang ngoeo. */
    public static void zigzag(ServerWorld w, PlayerEntity p, Breath b, double length) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();
        Vec3d base = p.getEyePos();
        double off = 0;
        for (double d = 0.5; d < length; d += 0.4) {
            off = (Math.sin(d * 2.7) + Math.cos(d * 1.3)) * 0.5;
            Vec3d c = base.add(look.multiply(d)).add(right.multiply(off)).add(up.multiply(off * 0.4));
            put(w, dust(b, 1.2f), c);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 1, 0.1, 0.1, 0.1, 0.05);
        }
    }

    /** Ham chinh: ve hieu ung dac trung theo hoi tho va kieu chieu. */
    public static void play(ServerWorld w, PlayerEntity p, Breath b, Techniques.Pattern pat, int range) {
        switch (pat) {
            case SLASH -> {
                crescent(w, p, b, 3.2, 2.6, 35);
                if (b == Breath.MOON) { crescent(w, p, b, 4.2, 2.0, -25); crescent(w, p, b, 5.2, 1.6, 80); }
                if (b == Breath.FLOWER) crescent(w, p, b, 3.6, 2.2, -50);
            }
            case PIERCE -> { trail(w, p, b, Math.min(range, 12)); }
            case DASH -> trail(w, p, b, 7);
            case RING -> { spiral(w, p, b, Math.min(6, range), 3, 3); ring(w, p, b, Math.min(6, range), 0.3); }
            case LAUNCH -> spiral(w, p, b, 2.5, 6, 4);
            case ULT -> {
                crescent(w, p, b, 3.5, 3.4, 30);
                crescent(w, p, b, 4.5, 3.0, -30);
                crescent(w, p, b, 5.5, 2.6, 90);
                spiral(w, p, b, 5, 7, 4);
                ring(w, p, b, 7, 0.2);
                ring(w, p, b, 4, 0.2);
            }
        }
        if (b == Breath.SUN) halo(w, p, b, 1.8);
        if (b == Breath.THUNDER) zigzag(w, p, b, 10);
        if (b == Breath.WIND && pat != Techniques.Pattern.RING) spiral(w, p, b, 2.2, 3, 2);
        if (b == Breath.WATER) crescent(w, p, b, 3.0, 2.8, 5);
    }
}
