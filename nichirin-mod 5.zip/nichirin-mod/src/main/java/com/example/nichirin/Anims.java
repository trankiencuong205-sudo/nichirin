package com.example.nichirin;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Cac chieu "dien anh" co hoat anh theo tung tick (chay tren may chu, dong bo qua hat):
 * rong nuoc/lua, loc xoay, trang khuyet xoay, set phan nhanh, chuoi vet chem Mat Troi.
 * Moi hoat anh co chuan bi -> tan cong -> va cham (hitbox thuc) -> ket thuc.
 */
public class Anims {
    public interface Anim { boolean tick(); }   // true = ket thuc

    private static final List<Anim> ACTIVE = new ArrayList<>();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (ACTIVE.isEmpty()) return;
            ACTIVE.removeIf(a -> {
                try { return a.tick(); } catch (Exception e) { return true; }
            });
        });
    }

    // ---------- helpers ----------
    private static ParticleEffect dust(int c, float s) { return new DustParticleEffect(c, s); }

    private static int lighten(int c) {
        int r = Math.min(255, ((c >> 16) & 255) + 90), g = Math.min(255, ((c >> 8) & 255) + 90), b = Math.min(255, (c & 255) + 90);
        return (r << 16) | (g << 8) | b;
    }

    private static void put(ServerWorld w, ParticleEffect pe, Vec3d v, int n, double spread) {
        w.spawnParticles(pe, v.x, v.y, v.z, n, spread, spread, spread, 0.0);
    }

    private static void putS(ServerWorld w, ParticleEffect pe, Vec3d v, int n, double spread, double speed) {
        w.spawnParticles(pe, v.x, v.y, v.z, n, spread, spread, spread, speed);
    }

    private static void snd(ServerWorld w, Vec3d v, SoundEvent s, float vol, float pitch) {
        w.playSound(null, v.x, v.y, v.z, s, SoundCategory.PLAYERS, vol, pitch);
    }

    private static List<LivingEntity> monsters(ServerWorld w, PlayerEntity p, Box box) {
        return w.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive() && e instanceof Monster);
    }

    private static void damage(ServerWorld w, PlayerEntity p, LivingEntity t, float dmg) {
        t.damage(w, w.getDamageSources().playerAttack(p), dmg);
    }

    private static Vec3d[] basis(Vec3d look) {
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();
        return new Vec3d[]{look, right, up};
    }

    // ============ RONG (nuoc / lua / ...) ============
    public static void dragon(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, SoundEvent sound, float dmg) {
        ACTIVE.add(new Dragon(w, p, color, main, sound, dmg));
    }

    private static class Dragon implements Anim {
        static final int PREP = 8, FLY = 26, FIN = 10;
        final ServerWorld w; final PlayerEntity p; final int color; final ParticleEffect main; final SoundEvent sound; final float dmg;
        Vec3d dir, right, up, start;
        int t = 0, ft = 0;
        boolean finishing = false;
        Vec3d impact;
        final List<Vec3d> path = new ArrayList<>();
        final Set<UUID> hit = new HashSet<>();

        Dragon(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, SoundEvent sound, float dmg) {
            this.w = w; this.p = p; this.color = color; this.main = main; this.sound = sound; this.dmg = dmg;
            this.dir = p.getRotationVec(1.0f);
        }

        public boolean tick() {
            if (t < PREP) { prep(); t++; return false; }
            if (t == PREP) {
                dir = p.getRotationVec(1.0f);
                Vec3d[] B = basis(dir);
                right = B[1]; up = B[2];
                start = p.getEyePos().add(dir.multiply(1.5)).add(0, -0.4, 0);
                snd(w, start, sound, 1.6f, 0.6f);
                snd(w, start, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.6f);
            }
            if (!finishing) {
                int f = t - PREP;
                Vec3d base = start.add(dir.multiply((f + 1) * 0.95));
                Vec3d head = base.add(right.multiply(Math.sin(f * 0.55) * 1.3)).add(up.multiply(Math.cos(f * 0.35) * 0.7));
                path.add(head);
                drawBody(head);
                boolean impactNow = !w.isAir(BlockPos.ofFloored(head.x, head.y, head.z));
                for (LivingEntity e : monsters(w, p, new Box(head, head).expand(2.2))) {
                    if (hit.add(e.getUuid())) {
                        damage(w, p, e, dmg);
                        e.addVelocity(dir.x * 0.9, 0.45, dir.z * 0.9);
                        putS(w, main, e.getEntityPos().add(0, 1, 0), 25, 0.5, 0.15);
                    }
                }
                if (impactNow || f >= FLY - 1) {
                    finishing = true;
                    impact = head;
                    snd(w, head, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.4f, 0.9f);
                    snd(w, head, sound, 1.8f, 0.5f);
                    for (LivingEntity e : monsters(w, p, new Box(head, head).expand(5, 3, 5))) {
                        if (hit.add(e.getUuid())) damage(w, p, e, dmg * 0.8f);
                        e.addVelocity((e.getX() - head.x) * 0.25, 0.6, (e.getZ() - head.z) * 0.25);
                    }
                    putS(w, ParticleTypes.EXPLOSION_EMITTER, head, 1, 0, 0);
                }
                t++;
                return false;
            }
            ft++;
            double r = ft * 0.9;
            int n = (int) (r * 10) + 14;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                Vec3d v = impact.add(Math.cos(a) * r, 0.1 + Math.sin(ft * 0.5) * 0.3, Math.sin(a) * r);
                put(w, dust(color, 1.6f), v, 1, 0.1);
                if (i % 3 == 0) putS(w, main, v, 2, 0.2, 0.08);
            }
            if (ft < 5) for (double y = 0; y < ft * 1.2; y += 0.5) put(w, dust(lighten(color), 1.4f), impact.add(0, y, 0), 3, 0.6);
            return ft >= FIN;
        }

        void prep() {
            if (t == 0) snd(w, p.getEntityPos(), sound, 1.0f, 0.8f);
            Vec3d c = p.getEntityPos();
            double r = 3.2 * (1 - (double) t / PREP) + 0.5;
            for (int k = 0; k < 18; k++) {
                double a = t * 0.7 + k * 0.35;
                Vec3d v = c.add(Math.cos(a) * r, 0.2 + k * 0.12, Math.sin(a) * r);
                put(w, dust(color, 1.3f), v, 1, 0.05);
                if (k % 4 == 0) putS(w, main, v, 1, 0.1, 0.03);
            }
        }

        void drawBody(Vec3d head) {
            int n = Math.min(path.size(), 15);
            for (int i = 0; i < n; i++) {
                int idx = Math.max(0, path.size() - 1 - i * 2);
                Vec3d seg = path.get(idx);
                double rad = i == 0 ? 1.15 : Math.max(0.35, 0.95 - i * 0.045);
                put(w, dust(color, 1.8f), seg, 7, rad * 0.55);
                put(w, dust(lighten(color), 1.1f), seg, 3, rad * 0.4);
                putS(w, main, seg, 2, rad * 0.5, 0.04);
                if (i % 3 == 0) putS(w, ParticleTypes.CLOUD, seg, 1, rad * 0.6, 0.02);
            }
            // dau rong: mat, sung, mieng
            Vec3d eyeL = head.add(up.multiply(0.4)).add(right.multiply(0.35)).add(dir.multiply(0.45));
            Vec3d eyeR = head.add(up.multiply(0.4)).add(right.multiply(-0.35)).add(dir.multiply(0.45));
            put(w, dust(0xFFFFFF, 1.0f), eyeL, 1, 0.0);
            put(w, dust(0xFFFFFF, 1.0f), eyeR, 1, 0.0);
            for (int s = -1; s <= 1; s += 2) {
                for (int k = 0; k < 6; k++) {
                    Vec3d hp = head.add(up.multiply(0.55 + k * 0.1)).add(right.multiply(0.3 * s + k * 0.06 * s)).add(dir.multiply(-0.15 * k));
                    put(w, dust(lighten(color), 1.0f), hp, 1, 0.0);
                }
            }
            putS(w, main, head.add(dir.multiply(0.9)), 8, 0.25, 0.1);
        }
    }

    // ============ LOC XOAY ============
    public static void tornado(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
        ACTIVE.add(new Tornado(w, p, color, main, dmg));
    }

    private static class Tornado implements Anim {
        final ServerWorld w; final PlayerEntity p; final int color; final ParticleEffect main; final float dmg;
        final Vec3d dir, start;
        int t = 0;
        static final int TOTAL = 30;

        Tornado(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
            this.w = w; this.p = p; this.color = color; this.main = main; this.dmg = dmg;
            Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
            this.dir = look.lengthSquared() > 1.0E-4 ? look.normalize() : new Vec3d(1, 0, 0);
            this.start = p.getEntityPos().add(dir.multiply(2.5));
            snd(w, start, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.4f, 0.5f);
        }

        public boolean tick() {
            Vec3d c = start.add(dir.multiply(t * 0.55));
            for (double h = 0; h <= 9; h += 0.45) {
                double r = 0.5 + h * 0.4;
                for (int k = 0; k < 3; k++) {
                    double a = t * 0.8 + h * 0.9 + k * Math.PI * 2 / 3;
                    Vec3d v = c.add(Math.cos(a) * r, h, Math.sin(a) * r);
                    put(w, dust(color, 1.5f), v, 2, 0.1);
                    if (k == 0) putS(w, ParticleTypes.CLOUD, v, 1, 0.15, 0.02);
                }
            }
            putS(w, main, c.add(0, 0.3, 0), 6, 1.0, 0.1);
            if (t % 6 == 0) snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.9f, 0.6f);
            if (t % 3 == 0) {
                for (LivingEntity e : monsters(w, p, new Box(c.x - 3.8, c.y - 1, c.z - 3.8, c.x + 3.8, c.y + 9, c.z + 3.8))) {
                    e.addVelocity((c.x - e.getX()) * 0.12, 0.5, (c.z - e.getZ()) * 0.12);
                    damage(w, p, e, dmg * 0.3f);
                }
            }
            t++;
            if (t >= TOTAL) {
                for (double rr = 1; rr <= 5; rr += 1) for (int i = 0; i < 30; i++) {
                    double a = i * Math.PI / 15;
                    putS(w, ParticleTypes.CLOUD, c.add(Math.cos(a) * rr, 0.4, Math.sin(a) * rr), 1, 0.1, 0.08);
                }
                for (LivingEntity e : monsters(w, p, new Box(c, c).expand(5, 3, 5))) { damage(w, p, e, dmg * 0.6f); e.addVelocity((e.getX() - c.x) * 0.3, 0.5, (e.getZ() - c.z) * 0.3); }
                return true;
            }
            return false;
        }
    }

    // ============ TRANG KHUYET XOAY ============
    public static void orbit(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
        ACTIVE.add(new Orbit(w, p, color, main, dmg));
    }

    private static class Orbit implements Anim {
        static final int N = 5, ORB = 20, TOTAL = 34;
        final ServerWorld w; final PlayerEntity p; final int color; final ParticleEffect main; final float dmg;
        int t = 0;
        Vec3d center;
        final Set<Long> hit = new HashSet<>();

        Orbit(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
            this.w = w; this.p = p; this.color = color; this.main = main; this.dmg = dmg;
            this.center = p.getEntityPos();
            snd(w, center, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.4f, 0.7f);
        }

        public boolean tick() {
            if (t < ORB) center = p.getEntityPos();
            for (int i = 0; i < N; i++) {
                double a = t * 0.4 + i * Math.PI * 2 / N;
                double R = t < ORB ? 2.6 : 2.6 + (t - ORB) * 1.0;
                Vec3d f = new Vec3d(Math.cos(a), 0, Math.sin(a));
                Vec3d T = new Vec3d(-Math.sin(a), 0, Math.cos(a));
                Vec3d c = center.add(f.multiply(R)).add(0, 1.3 + 0.4 * Math.sin(t * 0.3 + i), 0);
                double tilt = i * 0.6;
                Vec3d U = new Vec3d(0, Math.cos(tilt), 0).add(T.multiply(Math.sin(tilt)));
                for (int layer = 0; layer < 3; layer++) {
                    for (double s = -1; s <= 1.0001; s += 0.1) {
                        Vec3d pt = c.add(U.multiply(s * 1.5)).add(f.multiply((1 - s * s) * 0.6));
                        put(w, dust(color, layer == 1 ? 1.7f : 1.0f), pt.add(T.multiply((layer - 1) * 0.12)), 1, 0.0);
                    }
                }
                putS(w, ParticleTypes.END_ROD, c.add(U.multiply(1.5)), 1, 0.05, 0.01);
                putS(w, ParticleTypes.END_ROD, c.add(U.multiply(-1.5)), 1, 0.05, 0.01);
                for (LivingEntity e : monsters(w, p, new Box(c, c).expand(1.7))) {
                    long key = e.getUuid().getLeastSignificantBits() * 31 + i;
                    if (hit.add(key)) {
                        damage(w, p, e, dmg);
                        e.addVelocity(f.x * 0.5, 0.3, f.z * 0.5);
                        putS(w, main, e.getEntityPos().add(0, 1, 0), 15, 0.4, 0.1);
                    }
                }
            }
            if (t == ORB) snd(w, center, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.6f, 0.5f);
            t++;
            return t >= TOTAL;
        }
    }

    // ============ SET PHAN NHANH ============
    public static void bolt(ServerWorld w, PlayerEntity p, int color, float dmg) {
        ACTIVE.add(new Bolt(w, p, color, dmg));
    }

    private static class Bolt implements Anim {
        final ServerWorld w; final PlayerEntity p; final int color; final float dmg;
        final List<Vec3d> strikes = new ArrayList<>();
        int t = 0;

        Bolt(ServerWorld w, PlayerEntity p, int color, float dmg) {
            this.w = w; this.p = p; this.color = color; this.dmg = dmg;
            Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
            Vec3d tgt = eye.add(look.multiply(10));
            for (double d = 1; d <= 18; d += 0.5) {
                Vec3d c = eye.add(look.multiply(d));
                if (!w.isAir(BlockPos.ofFloored(c.x, c.y, c.z))) break;
                tgt = c;
            }
            strikes.add(tgt);
            int extra = 0;
            for (LivingEntity e : monsters(w, p, new Box(tgt, tgt).expand(10, 5, 10))) {
                if (extra++ >= 2) break;
                strikes.add(e.getEntityPos());
            }
            snd(w, tgt, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2.0f, 1.2f);
        }

        public boolean tick() {
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            if (t <= 5) {
                for (Vec3d s : strikes) {
                    Vec3d cur = s.add(rnd.nextDouble() * 2 - 1, 16, rnd.nextDouble() * 2 - 1);
                    List<Vec3d> pts = new ArrayList<>();
                    while (cur.y > s.y) {
                        pts.add(cur);
                        put(w, dust(0xFFF060, 1.9f), cur, 1, 0.05);
                        put(w, dust(0xFFFFFF, 0.9f), cur, 1, 0.0);
                        if (rnd.nextInt(3) == 0) putS(w, ParticleTypes.ELECTRIC_SPARK, cur, 1, 0.2, 0.1);
                        cur = new Vec3d(cur.x + (rnd.nextDouble() - 0.5) * 1.1, cur.y - 0.6, cur.z + (rnd.nextDouble() - 0.5) * 1.1);
                        double toX = s.x - cur.x, toZ = s.z - cur.z;
                        cur = new Vec3d(cur.x + toX * 0.08, cur.y, cur.z + toZ * 0.08);
                    }
                    // nhanh phu
                    for (int b = 0; b < 4 && !pts.isEmpty(); b++) {
                        Vec3d bs = pts.get(rnd.nextInt(pts.size()));
                        double ang = rnd.nextDouble() * Math.PI * 2;
                        Vec3d d = new Vec3d(Math.cos(ang), -0.5, Math.sin(ang));
                        Vec3d c = bs;
                        for (int k = 0; k < 6; k++) {
                            c = c.add(d.multiply(0.6)).add((rnd.nextDouble() - 0.5) * 0.4, 0, (rnd.nextDouble() - 0.5) * 0.4);
                            put(w, dust(0xFFE040, 1.1f), c, 1, 0.03);
                        }
                    }
                    putS(w, ParticleTypes.ELECTRIC_SPARK, s, 12, 0.8, 0.3);
                }
            }
            if (t == 1) {
                for (Vec3d s : strikes) {
                    putS(w, ParticleTypes.EXPLOSION, s.add(0, 0.5, 0), 3, 1.2, 0);
                    for (LivingEntity e : monsters(w, p, new Box(s, s).expand(4, 3, 4))) {
                        damage(w, p, e, dmg);
                        e.setFireTicks(60);
                    }
                }
            }
            t++;
            return t > 8;
        }
    }

    // ============ CHUOI VET CHEM MAT TROI ============
    public static void arcs(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
        ACTIVE.add(new Arcs(w, p, color, main, dmg));
    }

    private static class Arcs implements Anim {
        final ServerWorld w; final PlayerEntity p; final int c1, c2; final ParticleEffect main; final float dmg;
        int t = 0;
        static final double[] TILT = {-35, 35, -80, 90};

        Arcs(ServerWorld w, PlayerEntity p, int color, ParticleEffect main, float dmg) {
            this.w = w; this.p = p; this.c1 = color; this.c2 = lighten(color); this.main = main; this.dmg = dmg;
            snd(w, p.getEntityPos(), SoundEvents.ITEM_FIRECHARGE_USE, 1.3f, 0.8f);
        }

        public boolean tick() {
            int step = t / 5;
            if (t % 5 == 0 && step < 4) {
                Vec3d look = p.getRotationVec(1.0f);
                Vec3d[] B = basis(look);
                double tl = Math.toRadians(TILT[step]);
                Vec3d dirv = B[1].multiply(Math.cos(tl)).add(B[2].multiply(Math.sin(tl)));
                Vec3d center = p.getEyePos().add(look.multiply(3.2));
                for (int layer = 0; layer < 4; layer++) {
                    for (double s = -1; s <= 1.0001; s += 0.03) {
                        double bend = (1 - s * s) * 1.7;
                        Vec3d pt = center.add(dirv.multiply(s * 3.8)).add(look.multiply(bend)).add(B[0].multiply(layer * 0.08));
                        int col = layer < 2 ? c1 : c2;
                        put(w, dust(col, layer == 1 ? 2.0f : 1.2f), pt, 1, 0.04);
                        if (layer == 1 && ((int) (s * 100)) % 12 == 0) putS(w, main, pt, 2, 0.15, 0.05);
                    }
                }
                snd(w, center, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.9f + step * 0.1f);
                p.addVelocity(look.x * 0.45, 0.05, look.z * 0.45);
                Vec3d eye = p.getEyePos();
                for (LivingEntity e : monsters(w, p, new Box(eye, eye.add(look.multiply(6))).expand(1.8))) {
                    damage(w, p, e, dmg);
                    e.addVelocity(look.x * 0.5, 0.2, look.z * 0.5);
                    putS(w, ParticleTypes.EXPLOSION, e.getEntityPos().add(0, 1, 0), 1, 0.2, 0);
                }
            }
            if (t == 20) {
                Vec3d c = p.getEntityPos().add(0, 0.5, 0);
                for (int r = 0; r < 12; r++) {
                    double a = r * Math.PI / 6;
                    for (double d = 1; d < 6; d += 0.3) put(w, dust(r % 2 == 0 ? c1 : c2, 1.5f), c.add(Math.cos(a) * d, 0, Math.sin(a) * d), 1, 0.03);
                }
                for (double rr = 2; rr <= 6; rr += 2) for (int i = 0; i < 40; i++) {
                    double a = i * Math.PI / 20;
                    put(w, dust(c2, 1.4f), c.add(Math.cos(a) * rr, 0, Math.sin(a) * rr), 1, 0.03);
                }
                snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f, 1.1f);
                putS(w, ParticleTypes.EXPLOSION_EMITTER, c, 1, 0, 0);
                for (LivingEntity e : monsters(w, p, p.getBoundingBox().expand(6, 3, 6))) { damage(w, p, e, dmg * 1.5f); e.setFireTicks(80); }
            }
            t++;
            return t > 24;
        }
    }
}
