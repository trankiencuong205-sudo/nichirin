package com.example.nichirin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Hieu ung hat dac trung cho tung quy: trang khuyet, hoa bang, la ban, to nhen, trong, mui ten... */
public class DemonFx {
    static int color(DemonType d) {
        return switch (d) {
            case KOKUSHIBO -> 0x8A6CFF;
            case DOMA -> 0x9FE8FF;
            case AKAZA -> 0xFF5C9A;
            case HANTENGU -> 0xFFE24A;
            case GYOKKO -> 0x2FB0A0;
            case GYUTARO -> 0xC01830;
            case DAKI -> 0xFF3C78;
            case NAKIME -> 0xE0B040;
            case KAIGAKU -> 0x404040;
            case ENMU -> 0x8030C0;
            case RUI -> 0xF4F4F4;
            case MUZAN -> 0xA01040;
            case NEZUKO -> 0xFF7A30;
            case SUSAMARU -> 0x60E060;
            case YAHABA -> 0xB8B8B8;
            case KYOGAI -> 0xD8A840;
            default -> 0x902030;
        };
    }

    private static ParticleEffect dust(int c, float s) { return new DustParticleEffect(c, s); }

    private static void put(ServerWorld w, int c, float s, Vec3d v) { w.spawnParticles(dust(c, s), v.x, v.y, v.z, 1, 0.02, 0.02, 0.02, 0.0); }

    private static Vec3d[] basis(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();
        return new Vec3d[]{look, right, up};
    }

    private static void line(ServerWorld w, int c, float s, Vec3d a, Vec3d b, double step) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 1.0E-4) return;
        d = d.multiply(1 / len);
        for (double t = 0; t <= len; t += step) put(w, c, s, a.add(d.multiply(t)));
    }

    private static void crescent(ServerWorld w, PlayerEntity p, int c, double dist, double radius, double tiltDeg) {
        Vec3d[] B = basis(p);
        double t = Math.toRadians(tiltDeg);
        Vec3d dir = B[1].multiply(Math.cos(t)).add(B[2].multiply(Math.sin(t)));
        Vec3d center = p.getEyePos().add(B[0].multiply(dist));
        for (int layer = 0; layer < 3; layer++) {
            for (double s = -1; s <= 1.0001; s += 0.05) {
                double bend = (1 - s * s) * radius * 0.45;
                Vec3d pt = center.add(dir.multiply(s * radius)).add(B[0].multiply(bend));
                put(w, c, layer == 1 ? 1.6f : 1.0f, pt.add(B[2].multiply((layer - 1) * 0.1)));
            }
        }
    }

    private static void ringH(ServerWorld w, int c, Vec3d center, double r, float s) {
        int n = (int) (r * 14) + 12;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            put(w, c, s, center.add(Math.cos(a) * r, 0, Math.sin(a) * r));
        }
    }

    private static void ringV(ServerWorld w, int c, Vec3d center, Vec3d right, Vec3d up, double r, float s) {
        int n = (int) (r * 14) + 12;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            put(w, c, s, center.add(right.multiply(Math.cos(a) * r)).add(up.multiply(Math.sin(a) * r)));
        }
    }

    private static void rose(ServerWorld w, int c, Vec3d center, double R, int k) {
        for (double a = 0; a < Math.PI * 2; a += 0.04) {
            double r = R * Math.abs(Math.cos(k * a));
            put(w, c, 1.2f, center.add(Math.cos(a) * r, 0, Math.sin(a) * r));
        }
    }

    private static void spiral(ServerWorld w, int c, Vec3d center, double radius, double height, int turns) {
        int n = turns * 36;
        for (int i = 0; i < n; i++) {
            double f = (double) i / n, a = f * turns * Math.PI * 2, r = radius * (0.35 + 0.65 * f);
            put(w, c, 1.3f, center.add(Math.cos(a) * r, f * height, Math.sin(a) * r));
        }
    }

    private static void wave(ServerWorld w, int c, Vec3d start, Vec3d dir, Vec3d side, double len, double amp, double freq) {
        for (double t = 0; t < len; t += 0.2) put(w, c, 1.2f, start.add(dir.multiply(t)).add(side.multiply(Math.sin(t * freq) * amp)));
    }

    public static void play(ServerWorld w, PlayerEntity p, DemonType d, int idx, DemonArts.Pattern pat) {
        int c = color(d);
        int v = idx % 2;
        Vec3d[] B = basis(p);
        Vec3d look = B[0], right = B[1], up = B[2];
        Vec3d eye = p.getEyePos(), feet = p.getEntityPos().add(0, 0.25, 0), front = eye.add(look.multiply(3));

        // --- hinh co ban theo kieu chieu ---
        switch (pat) {
            case SLASH, PIERCE -> crescent(w, p, c, 3.2, 2.4, v == 0 ? 30 : -30);
            case DASH -> line(w, c, 1.4f, p.getEntityPos().add(0, 1, 0), p.getEntityPos().add(0, 1, 0).add(look.multiply(-7)), 0.25);
            case RING -> { ringH(w, c, feet, 5, 1.2f); ringH(w, c, feet, 3, 1.2f); }
            case LAUNCH -> spiral(w, c, p.getEntityPos(), 2.5, 6, 3);
            case ULT -> { crescent(w, p, c, 3.5, 3.4, 30); crescent(w, p, c, 4.5, 3.0, -30); ringH(w, c, feet, 7, 1.4f); spiral(w, c, p.getEntityPos(), 5, 7, 4); }
            case TRAP -> { ringH(w, c, feet, 6, 1.2f); ringV(w, c, front, right, up, 2, 1.2f); }
            case BLINK -> { for (double y = 0; y < 3; y += 0.2) put(w, c, 1.4f, p.getEntityPos().add(0, y, 0)); }
            case HEAL -> spiral(w, c, p.getEntityPos(), 1.0, 3, 3);
            case PULL -> { for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4; line(w, c, 1.1f, feet.add(Math.cos(a) * 6, 0.5, Math.sin(a) * 6), feet.add(0, 0.5, 0), 0.3); } }
        }

        // --- dac trung rieng cua tung quy ---
        switch (d) {
            case KOKUSHIBO -> { crescent(w, p, c, 4.2, 2.0, -25); crescent(w, p, c, 5.2, 1.6, 80); }
            case DOMA -> {
                rose(w, c, feet, 5, 3);
                if (v == 1) rose(w, c, feet.add(0, 0.3, 0), 3, 5);
                w.spawnParticles(ParticleTypes.SNOWFLAKE, feet.x, feet.y + 1, feet.z, 40, 3, 1.5, 3, 0.02);
            }
            case AKAZA -> {
                ringH(w, c, feet, 4, 1.3f);
                for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4; line(w, c, 1.2f, feet, feet.add(Math.cos(a) * 4, 0, Math.sin(a) * 4), 0.3); }
                if (v == 1) ringH(w, c, feet.add(0, 0.1, 0), 2, 1.3f);
            }
            case HANTENGU -> {
                for (int k = -1; k <= 1; k += 2) {
                    Vec3d s = eye.add(right.multiply(k * 1.2));
                    for (double t = 0.5; t < 9; t += 0.4) {
                        Vec3d pt = s.add(look.multiply(t)).add(right.multiply(Math.sin(t * 2.5) * 0.5 * k)).add(up.multiply(Math.cos(t * 1.7) * 0.3));
                        put(w, c, 1.2f, pt);
                        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.1, 0.1, 0.1, 0.05);
                    }
                }
            }
            case GYOKKO -> {
                for (int i = 0; i < 16; i++) {
                    Vec3d b = feet.add((Math.random() - 0.5) * 8, Math.random() * 3, (Math.random() - 0.5) * 8);
                    for (int j = 0; j < 10; j++) { double a = j * Math.PI / 5; put(w, c, 0.9f, b.add(Math.cos(a) * 0.35, Math.sin(a) * 0.35, 0)); }
                    w.spawnParticles(ParticleTypes.BUBBLE_POP, b.x, b.y, b.z, 2, 0.1, 0.1, 0.1, 0.0);
                }
            }
            case GYUTARO -> { crescent(w, p, c, 3.4, 2.6, 45); crescent(w, p, c, 3.8, 2.6, -45); }
            case DAKI -> {
                for (int k = -1; k <= 1; k++) wave(w, c, eye.add(right.multiply(k * 0.8)).add(look), look, up, 8, 0.5, 2.2 + k * 0.3);
            }
            case NAKIME -> {
                for (int k = 0; k < 3; k++) {
                    Vec3d ctr = eye.add(look.multiply(3 + k * 1.5)).add(right.multiply((k - 1) * 1.6));
                    for (double a = -0.6; a <= 0.6; a += 0.2) {
                        put(w, c, 1.1f, ctr.add(right.multiply(a)).add(up.multiply(-1.0)));
                        put(w, c, 1.1f, ctr.add(right.multiply(a)).add(up.multiply(1.0)));
                    }
                    for (double y = -1; y <= 1; y += 0.2) { put(w, c, 1.1f, ctr.add(right.multiply(-0.6)).add(up.multiply(y))); put(w, c, 1.1f, ctr.add(right.multiply(0.6)).add(up.multiply(y))); }
                    w.spawnParticles(ParticleTypes.NOTE, ctr.x, ctr.y, ctr.z, 2, 0.3, 0.3, 0.3, 0.5);
                }
            }
            case KAIGAKU -> {
                for (double t = 0.5; t < 10; t += 0.35) {
                    Vec3d pt = eye.add(look.multiply(t)).add(right.multiply(Math.sin(t * 3) * 0.6));
                    put(w, 0x202020, 1.6f, pt);
                    w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.1, 0.1, 0.1, 0.05);
                }
            }
            case ENMU -> { spiral(w, 0x8030C0, p.getEntityPos(), 4, 4, 4); w.spawnParticles(ParticleTypes.SOUL, feet.x, feet.y + 1, feet.z, 20, 2, 1, 2, 0.02); }
            case RUI -> {
                Vec3d ctr = eye.add(look.multiply(3));
                for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4; line(w, c, 1.0f, ctr, ctr.add(right.multiply(Math.cos(a) * 2.6)).add(up.multiply(Math.sin(a) * 2.6)), 0.2); }
                for (double r = 0.8; r <= 2.6; r += 0.6) ringV(w, c, ctr, right, up, r, 0.9f);
            }
            case MUZAN -> {
                for (int i = 0; i < 6; i++) {
                    double a = i * Math.PI / 3;
                    Vec3d dir = new Vec3d(Math.cos(a), 0, Math.sin(a));
                    wave(w, c, feet.add(0, 1, 0), dir, new Vec3d(0, 1, 0), 6, 0.6, 2.0 + i * 0.2);
                }
            }
            case NEZUKO -> { spiral(w, 0xFF7A30, p.getEntityPos(), 3, 5, 3); w.spawnParticles(ParticleTypes.FLAME, feet.x, feet.y + 0.5, feet.z, 30, 2, 0.5, 2, 0.03); }
            case SUSAMARU -> {
                for (int k = 0; k < 5; k++) {
                    double a = k * Math.PI * 2 / 5;
                    Vec3d ctr = feet.add(Math.cos(a) * 3, 1.2, Math.sin(a) * 3);
                    for (int j = 0; j < 20; j++) { double th = Math.random() * Math.PI * 2, ph = Math.random() * Math.PI; put(w, c, 0.9f, ctr.add(Math.sin(ph) * Math.cos(th) * 0.5, Math.cos(ph) * 0.5, Math.sin(ph) * Math.sin(th) * 0.5)); }
                }
            }
            case YAHABA -> {
                for (int k = -1; k <= 1; k++) {
                    Vec3d s = eye.add(right.multiply(k * 1.2)), e = s.add(look.multiply(6));
                    line(w, c, 1.2f, s, e, 0.25);
                    line(w, c, 1.2f, e, e.add(look.multiply(-0.8)).add(right.multiply(0.5)), 0.15);
                    line(w, c, 1.2f, e, e.add(look.multiply(-0.8)).add(right.multiply(-0.5)), 0.15);
                }
            }
            case KYOGAI -> {
                for (int k = 0; k < 4; k++) ringV(w, c, eye.add(look.multiply(2 + k * 1.6)), right, up, 1.0 + k * 0.4, 1.3f);
                w.spawnParticles(ParticleTypes.NOTE, eye.x + look.x * 3, eye.y + look.y * 3, eye.z + look.z * 3, 6, 1, 0.5, 1, 0.5);
            }
            default -> crescent(w, p, c, 3.5, 2.2, v == 0 ? 60 : -60);
        }
    }
}
