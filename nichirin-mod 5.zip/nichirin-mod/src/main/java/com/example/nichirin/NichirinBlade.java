package com.example.nichirin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/** Kiem Nichirin. breath == null nghia la kiem da hoi tho (theo hoi tho chon trong GUI, phim K). */
public class NichirinBlade extends Item {
    private final Breath breath;

    public NichirinBlade(Settings settings, Breath breath) {
        super(settings);
        this.breath = breath;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        user.swingHand(hand);
        if (!(world instanceof ServerWorld sw)) return ActionResult.SUCCESS;
        UUID id = user.getUuid();
        Breath b = breath != null ? breath : PlayerData.chosen(id);
        List<Techniques.Tech> list = Techniques.of(b);
        int idx = PlayerData.selected(id, b);

        if (user.isSneaking()) { // doi thuc nhanh
            idx = (idx + 1) % list.size();
            PlayerData.select(id, b, idx);
            Techniques.Tech t = list.get(idx);
            user.sendMessage(Text.literal("Thức " + t.num() + ": " + t.vn() + (t.canon() ? "" : " [Custom Skill]")).formatted(b.color, Formatting.BOLD), true);
            sw.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE.value(), net.minecraft.sound.SoundCategory.PLAYERS, 1.0f, 1.4f);
            PlayerData.sync((net.minecraft.server.network.ServerPlayerEntity) user);
            return ActionResult.SUCCESS;
        }

        Techniques.Tech t = list.get(idx);
        String key = "T." + b.name() + "." + t.num();
        int cost = Config.cost(key, t.energy());
        if (!user.isCreative() && PlayerData.energy(id) < cost) {
            user.sendMessage(Text.literal("Không đủ năng lượng! Cần " + cost + ", có " + (int) PlayerData.energy(id)).formatted(Formatting.RED), true);
            return ActionResult.FAIL;
        }
        int lv = PlayerData.level(id, b, idx);
        Skills.run(sw, user, t, 1.0 + 0.15 * lv);
        if (!user.isCreative()) PlayerData.setEnergy(id, PlayerData.energy(id) - cost);
        int cd = Config.cooldown(key, t.cooldown());
        if (cd > 0) user.getItemCooldownManager().set(user.getStackInHand(hand), cd);
        user.sendMessage(Text.literal("Thức " + t.num() + ": " + t.vn() + "  (NL " + (int) PlayerData.energy(id) + "/" + PlayerData.maxEnergy(id) + ")").formatted(b.color), true);
        PlayerData.sync((net.minecraft.server.network.ServerPlayerEntity) user);
        return ActionResult.SUCCESS;
    }
}
