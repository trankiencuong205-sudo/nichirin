package com.example.nichirin;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Quy theo tung nhan vat (dung mob vanilla doi ten/chi so) va kiem si dong minh. */
public class Mobs {
    public static final String ART_TAG = "nichirin_art_";

    static EntityType<? extends MobEntity> typeOf(DemonType d) {
        return switch (d) {
            case KOKUSHIBO, KAIGAKU -> EntityType.WITHER_SKELETON;
            case DOMA -> EntityType.STRAY;
            case AKAZA -> EntityType.PIGLIN_BRUTE;
            case HANTENGU -> EntityType.ZOMBIE_VILLAGER;
            case GYOKKO -> EntityType.DROWNED;
            case GYUTARO -> EntityType.VINDICATOR;
            case DAKI -> EntityType.WITCH;
            case NAKIME -> EntityType.ENDERMAN;
            case ENMU -> EntityType.HUSK;
            case RUI -> EntityType.SPIDER;
            case NEZUKO -> EntityType.BLAZE;
            case KYOGAI -> EntityType.SKELETON;
            case SUSAMARU, YAHABA, MUKAGO -> EntityType.CAVE_SPIDER;
            default -> EntityType.ZOMBIE;
        };
    }

    static double hp(DemonType d) {
        return switch (d) {
            case MUZAN -> 600;
            case KOKUSHIBO, DOMA, AKAZA -> 300;
            case HANTENGU, GYOKKO, GYUTARO, DAKI, NAKIME, KAIGAKU -> 220;
            case ENMU, RUI, NEZUKO, KYOGAI -> 160;
            default -> 100;
        };
    }

    static double dmg(DemonType d) {
        return switch (d) {
            case MUZAN -> 20;
            case KOKUSHIBO, DOMA, AKAZA -> 16;
            case HANTENGU, GYOKKO, GYUTARO, DAKI, NAKIME, KAIGAKU -> 12;
            default -> 8;
        };
    }

    private static void place(PlayerEntity p, MobEntity m, double dist) {
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        look = look.lengthSquared() > 1.0E-4 ? look.normalize().multiply(dist) : new Vec3d(dist, 0, 0);
        m.setPosition(p.getX() + look.x, p.getY(), p.getZ() + look.z);
    }

    private static void stats(MobEntity m, double hp, double dmg) {
        if (m.getAttributeInstance(EntityAttributes.MAX_HEALTH) != null) m.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(hp);
        if (m.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE) != null) m.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(dmg);
        m.setHealth((float) hp);
    }

    public static void spawnDemon(ServerWorld w, PlayerEntity p, DemonType d) {
        MobEntity m = typeOf(d).create(w, SpawnReason.TRIGGERED);
        if (m == null) return;
        place(p, m, 4);
        stats(m, hp(d), dmg(d));
        m.setCustomName(Text.literal(d.title).formatted(d.color, Formatting.BOLD));
        m.setCustomNameVisible(true);
        m.setPersistent();
        m.addCommandTag(Nichirin.DEMON_TAG);
        m.addCommandTag(ART_TAG + d.name());
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1000000, 2, false, false));
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 1000000, 0, false, false));
        w.spawnEntity(m);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 1.0f, 1.2f);
    }

    static String allyName(Breath b) {
        return switch (b) {
            case WATER -> "Thủy Trụ";
            case FIRE -> "Viêm Trụ";
            case WIND -> "Phong Trụ";
            case STONE -> "Nham Trụ";
            case MIST -> "Vụ Trụ";
            case SOUND -> "Âm Trụ";
            case LOVE -> "Luyến Trụ";
            case SERPENT -> "Xà Trụ";
            case FLOWER -> "Hoa Trụ";
            case INSECT -> "Trùng Trụ";
            default -> "Kiếm Sĩ " + b.title;
        };
    }

    public static void spawnAlly(ServerWorld w, PlayerEntity p, Breath b) {
        IronGolemEntity g = EntityType.IRON_GOLEM.create(w, SpawnReason.TRIGGERED);
        if (g == null) return;
        place(p, g, 3);
        stats(g, 150, 30);
        g.setPlayerCreated(true);
        g.setCustomName(Text.literal(allyName(b)).formatted(b.color, Formatting.BOLD));
        g.setCustomNameVisible(true);
        g.setPersistent();
        g.addCommandTag(Nichirin.ALLY_TAG);
        g.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1000000, 1, false, false));
        g.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1000000, 1, false, false));
        w.spawnEntity(g);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0f, 1.3f);
    }

    /** Quy tu dung Huyet Quy Thuat len nguoi choi o gan (moi ~2 giay). */
    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 40 != 0) return;
            for (ServerWorld w : server.getWorlds()) {
                for (ServerPlayerEntity p : w.getPlayers()) {
                    List<MobEntity> mobs = w.getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(24), e -> e.isAlive() && e.getCommandTags().contains(Nichirin.DEMON_TAG));
                    for (MobEntity m : mobs) {
                        DemonType d = null;
                        for (String t : m.getCommandTags()) {
                            if (t.startsWith(ART_TAG)) {
                                try { d = DemonType.valueOf(t.substring(ART_TAG.length())); } catch (Exception ignored) { }
                            }
                        }
                        if (d == null) continue;
                        LivingEntity target = m.getTarget();
                        if (!(target instanceof PlayerEntity) || target.squaredDistanceTo(m) > 100) continue;
                        Vec3d c = m.getEntityPos().add(0, 1, 0);
                        for (int i = 0; i < 24; i++) {
                            double a = i * Math.PI / 12;
                            w.spawnParticles(DemonSkills.main(d), c.x + Math.cos(a) * 1.5, c.y, c.z + Math.sin(a) * 1.5, 1, 0.1, 0.1, 0.1, 0.02);
                        }
                        w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, target.getX(), target.getY() + 1, target.getZ(), 3, 0.3, 0.3, 0.3, 0.0);
                        DemonSkills.extra(d, target);
                        target.damage(w, w.getDamageSources().magic(), (float) (dmg(d) * 0.4));
                    }
                }
            }
        });
    }
}
