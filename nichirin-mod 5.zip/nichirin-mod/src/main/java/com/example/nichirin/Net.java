package com.example.nichirin;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.UUID;

public class Net {
    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> PlayerData.sync(handler.player));

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            UUID id = p.getUuid();
            Breath[] all = Breath.values();
            DemonType[] dts = DemonType.values();
            int act = payload.action();
            if (act == 7) {
                if (p.isCreative() || context.server().isSingleplayer()) Config.set(payload.breath(), payload.idx());
                else p.sendMessage(Text.literal("Chỉ chủ thế giới hoặc người chơi creative mới đổi được cài đặt.").formatted(Formatting.RED), true);
                PlayerData.sync(p);
                return;
            }
            if (act >= 4 && act <= 6 && payload.breath() >= 0 && payload.breath() < dts.length) {
                DemonType d = dts[payload.breath()];
                int n = DemonArts.of(d).size();
                int idx = payload.idx();
                switch (act) {
                    case 4 -> { if (idx >= 0 && idx < n) PlayerData.selectArt(id, d, idx); }
                    case 5 -> {
                        if (idx < 0 || idx >= n) break;
                        int lv = PlayerData.levelArt(id, d, idx);
                        if (lv >= PlayerData.MAX_LEVEL) { p.sendMessage(Text.literal("Đã đạt cấp tối đa!").formatted(Formatting.YELLOW), true); break; }
                        int cost = 3 + lv * 2;
                        if (!p.isCreative() && p.experienceLevel < cost) {
                            p.sendMessage(Text.literal("Cần " + cost + " cấp kinh nghiệm để nâng cấp!").formatted(Formatting.RED), true);
                            break;
                        }
                        if (!p.isCreative()) p.addExperienceLevels(-cost);
                        PlayerData.setLevelArt(id, d, idx, lv + 1);
                        p.sendMessage(Text.literal("Nâng cấp thành công: cấp " + (lv + 1)).formatted(Formatting.GREEN), true);
                    }
                    case 6 -> PlayerData.chooseDemon(id, d);
                    default -> { }
                }
            } else if (act < 4 && payload.breath() >= 0 && payload.breath() < all.length) {
                Breath b = all[payload.breath()];
                int n = Techniques.of(b).size();
                int idx = payload.idx();
                switch (payload.action()) {
                    case 0 -> { if (idx >= 0 && idx < n) PlayerData.select(id, b, idx); }
                    case 1 -> {
                        if (idx < 0 || idx >= n) break;
                        int lv = PlayerData.level(id, b, idx);
                        if (lv >= PlayerData.MAX_LEVEL) { p.sendMessage(Text.literal("Đã đạt cấp tối đa!").formatted(Formatting.YELLOW), true); break; }
                        int cost = 3 + lv * 2;
                        if (!p.isCreative() && p.experienceLevel < cost) {
                            p.sendMessage(Text.literal("Cần " + cost + " cấp kinh nghiệm để nâng cấp!").formatted(Formatting.RED), true);
                            break;
                        }
                        if (!p.isCreative()) p.addExperienceLevels(-cost);
                        PlayerData.setLevel(id, b, idx, lv + 1);
                        p.sendMessage(Text.literal("Nâng cấp thành công: cấp " + (lv + 1)).formatted(Formatting.GREEN), true);
                    }
                    case 3 -> PlayerData.choose(id, b);
                    default -> { }
                }
            }
            PlayerData.sync(p);
        });
    }
}
