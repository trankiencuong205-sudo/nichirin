package com.example.nichirin;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Cai dat nang luong / hoi chieu / quy. Chi chu the gioi (hoac creative) moi doi duoc; may chu luu lai. */
public class SettingsScreen extends Screen {
    private static final String[] NAMES = {"Năng lượng tối đa", "Hồi năng lượng /giây", "Hệ số tiêu hao NL (%)", "Hệ số hồi chiêu (%)",
            "Tắt hồi chiêu", "Năng lượng vô hạn", "Cho phép thuốc giải quỷ", "Khát máu của quỷ"};
    private static final int[] STEP = {10, 5, 25, 25, 0, 0, 0, 0};

    public SettingsScreen() { super(Text.literal("Cài đặt Nichirin")); }

    @Override
    protected void init() {
        ClientData.listener = this::clearAndInit;
        int x = width / 2 - 150, y = 40;
        for (int i = 0; i < NAMES.length; i++) {
            final int idx = i;
            int v = ClientData.cfg[i];
            if (i >= 4) {
                String label = NAMES[i] + ": " + (v != 0 ? "BẬT" : "TẮT");
                addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> send(idx, ClientData.cfg[idx] != 0 ? 0 : 1))
                        .dimensions(x, y + i * 24, 300, 20).build());
            } else {
                String val = i == 1 ? String.format("%.1f", v / 10.0) : String.valueOf(v);
                addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> send(idx, Math.max(0, ClientData.cfg[idx] - STEP[idx])))
                        .dimensions(x, y + i * 24, 24, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal(NAMES[i] + ": " + val), b -> { })
                        .dimensions(x + 28, y + i * 24, 244, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> send(idx, ClientData.cfg[idx] + STEP[idx]))
                        .dimensions(x + 276, y + i * 24, 24, 20).build());
            }
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Quay lại"), b -> client.setScreen(new BreathScreen()))
                .dimensions(x, y + NAMES.length * 24 + 6, 300, 20)
                .tooltip(Tooltip.of(Text.literal("Cài đặt riêng từng kỹ năng: sửa file config/nichirin-config.properties (cost.T.WATER.8=..., cd.A.DOMA.3=...)"))).build());
    }

    private void send(int idx, int value) {
        ClientPlayNetworking.send(new ActionPayload(7, idx, value));
    }

    @Override
    public void removed() { ClientData.listener = null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Cài đặt năng lượng, hồi chiêu và quỷ").formatted(Formatting.AQUA), width / 2 - 100, 18, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Chỉ chủ thế giới hoặc người chơi creative mới đổi được. Máy chủ lưu lại.").formatted(Formatting.GRAY), width / 2 - 150, height - 14, 0xFFFFFFFF);
    }
}
