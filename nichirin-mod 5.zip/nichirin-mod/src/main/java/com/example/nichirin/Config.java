package com.example.nichirin;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Cai dat may chu (luu config/nichirin-config.properties).
 * Co the ghi de rieng tung ky nang bang dong "cost.T.WATER.8=20", "cd.T.WATER.8=100", "cost.A.DOMA.3=15" ...
 */
public class Config {
    public static int maxEnergy = 100;
    public static double regen = 2.0;       // nang luong / giay
    public static double costMult = 1.0;
    public static double cdMult = 1.0;
    public static boolean noCooldown = false;
    public static boolean unlimited = false;
    public static boolean allowCure = true;
    public static boolean hunger = true;

    private static final Map<String, Integer> COST = new HashMap<>();
    private static final Map<String, Integer> CD = new HashMap<>();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nichirin-config.properties"); }

    public static int cost(String key, int def) {
        if (unlimited) return 0;
        return (int) Math.round(COST.getOrDefault(key, def) * costMult);
    }

    public static int cooldown(String key, int def) {
        if (noCooldown) return 0;
        return (int) Math.round(CD.getOrDefault(key, def) * cdMult);
    }

    /** Thu tu: 0 maxEnergy, 1 regen*10, 2 costMult*100, 3 cdMult*100, 4 noCooldown, 5 unlimited, 6 allowCure, 7 hunger */
    public static int[] asArray() {
        return new int[]{maxEnergy, (int) Math.round(regen * 10), (int) Math.round(costMult * 100), (int) Math.round(cdMult * 100),
                noCooldown ? 1 : 0, unlimited ? 1 : 0, allowCure ? 1 : 0, hunger ? 1 : 0};
    }

    public static void set(int idx, int v) {
        switch (idx) {
            case 0 -> maxEnergy = Math.max(10, Math.min(1000, v));
            case 1 -> regen = Math.max(0, Math.min(100, v / 10.0));
            case 2 -> costMult = Math.max(0, Math.min(10, v / 100.0));
            case 3 -> cdMult = Math.max(0, Math.min(10, v / 100.0));
            case 4 -> noCooldown = v != 0;
            case 5 -> unlimited = v != 0;
            case 6 -> allowCure = v != 0;
            case 7 -> hunger = v != 0;
            default -> { return; }
        }
        save();
    }

    public static String sync() {
        int[] a = asArray();
        StringBuilder sb = new StringBuilder("cfg=");
        for (int v : a) sb.append(v).append(',');
        return sb.toString();
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) { save(); return; }
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) { p.load(in); }
            maxEnergy = Integer.parseInt(p.getProperty("maxEnergy", "100"));
            regen = Double.parseDouble(p.getProperty("regenPerSecond", "2.0"));
            costMult = Double.parseDouble(p.getProperty("costMultiplier", "1.0"));
            cdMult = Double.parseDouble(p.getProperty("cooldownMultiplier", "1.0"));
            noCooldown = Boolean.parseBoolean(p.getProperty("disableCooldowns", "false"));
            unlimited = Boolean.parseBoolean(p.getProperty("unlimitedEnergy", "false"));
            allowCure = Boolean.parseBoolean(p.getProperty("allowCure", "true"));
            hunger = Boolean.parseBoolean(p.getProperty("bloodHunger", "true"));
            for (String k : p.stringPropertyNames()) {
                try {
                    if (k.startsWith("cost.")) COST.put(k.substring(5), Integer.parseInt(p.getProperty(k)));
                    else if (k.startsWith("cd.")) CD.put(k.substring(3), Integer.parseInt(p.getProperty(k)));
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            p.setProperty("maxEnergy", String.valueOf(maxEnergy));
            p.setProperty("regenPerSecond", String.valueOf(regen));
            p.setProperty("costMultiplier", String.valueOf(costMult));
            p.setProperty("cooldownMultiplier", String.valueOf(cdMult));
            p.setProperty("disableCooldowns", String.valueOf(noCooldown));
            p.setProperty("unlimitedEnergy", String.valueOf(unlimited));
            p.setProperty("allowCure", String.valueOf(allowCure));
            p.setProperty("bloodHunger", String.valueOf(hunger));
            COST.forEach((k, v) -> p.setProperty("cost." + k, String.valueOf(v)));
            CD.forEach((k, v) -> p.setProperty("cd." + k, String.valueOf(v)));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Nichirin config - per-skill override: cost.T.<BREATH>.<num>, cd.T.<BREATH>.<num>, cost.A.<DEMON>.<num>, cd.A.<DEMON>.<num>"); }
        } catch (Exception ignored) { }
    }
}
