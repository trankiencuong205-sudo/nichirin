package com.example.nichirin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Thuc thi Huyet Quy Thuat. Chi gay sat thuong len quai hostile. */
public class DemonSkills {

    public static void run(ServerWorld w, PlayerEntity p, DemonArts.Art a, double mult) {
        DemonType d = a.demon();
        float dmg = (float) (a.damage() * mult);
        sound(w, p, soundOf(d), 1.0f);
        switch (a.pattern()) {
            case SLASH -> line(w, p, d, dmg, a.range(), 1.3);
            case PIERCE -> line(w, p, d, dmg, a.range(), 0.9);
            case DASH -> { dash(p); line(w, p, d, dmg, a.range(), 1.5); }
            case RING -> ring(w, p, d, dmg, Math.min(8, a.range() * 1.2), 1.3);
            case LAUNCH -> launch(w, p, d, dmg);
            case ULT -> ult(w, p, d, dmg, a.range());
            case TRAP -> trap(w, p, d, a.range());
            case BLINK -> blink(w, p, d, a.range());
            case HEAL -> heal(w, p, d);
            case PULL -> pull(w, p, d, dmg, a.range());
        }
    }

    // ---------- style per demon ----------
    private static SoundEvent soundOf(DemonType d) {
        return switch (d) {
            case DOMA -> SoundEvents.BLOCK_GLASS_BREAK;
            case GYOKKO -> SoundEvents.ENTITY_PLAYER_SPLASH;
            case KAIGAKU, HANTENGU -> SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER;
            case NAKIME, KYOGAI -> SoundEvents.BLOCK_NOTE_BLOCK_BASS.value();
            case NEZUKO -> SoundEvents.ITEM_FIRECHARGE_USE;
            case RUI, DAKI -> SoundEvents.ENTITY_SPIDER_AMBIENT;
            case MUZAN -> SoundEvents.ENTITY_RAVAGER_ATTACK;
            default -> SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP;
        };
    }

    public static ParticleEffect main(DemonType d) {
        return switch (d) {
            case KOKUSHIBO -> ParticleTypes.END_ROD;
            case DOMA -> ParticleTypes.SNOWFLAKE;
            case AKAZA -> ParticleTypes.CRIT;
            case HANTENGU, KAIGAKU -> ParticleTypes.ELECTRIC_SPARK;
            case GYOKKO -> ParticleTypes.BUBBLE_POP;
            case NAKIME, KYOGAI -> ParticleTypes.NOTE;
            case ENMU -> ParticleTypes.SOUL;
            case RUI -> ParticleTypes.CLOUD;
            case NEZUKO -> ParticleTypes.FLAME;
            case SUSAMARU -> ParticleTypes.POOF;
            case YAHABA -> ParticleTypes.SWEEP_ATTACK;
            default -> ParticleTypes.CRIMSON_SPORE;
        };
    }

    private static void extra(DemonType d, LivingEntity t) {
        switch (d) {
            case KOKUSHIBO -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 0));
            case DOMA -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 3));
            case GYUTARO, KYOKO -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 1));
            case ENMU -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
            case NEZUKO -> t.setFireTicks(120);
            case KYOGAI -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 1));
            case KAIGAKU, HANTENGU -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
            case RUI, DAKI -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
            default -> { }
        }
    }

    // ---------- helpers ----------
    private static List<LivingEntity> targets(ServerWorld w, PlayerEntity p, Box b) {
        return w.getEntitiesByClass(LivingEntity.class, b, e -> e != p && e.isAlive() && e instanceof Monster);
    }

    private static void hit(ServerWorld w, PlayerEntity p, DemonType d, LivingEntity t, float dmg, double kb) {
        extra(d, t);
        t.damage(w, w.getDamageSources().playerAttack(p), dmg);
        Vec3d v = t.getEntityPos().subtract(p.getEntityPos()).multiply(1, 0, 1);
        if (v.lengthSquared() > 1.0E-4) {
            v = v.normalize();
            t.addVelocity(v.x * kb, 0.3, v.z * kb);
            t.velocityModified = true;
        }
    }

    private static void fx(ServerWorld w, ParticleEffect pe, Vec3d v, int n, double s, double sp) {
        w.spawnParticles(pe, v.x, v.y, v.z, n, s, s, s, sp);
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent s, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, 1.0f, pitch);
    }

    private static void dash(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f);
        p.addVelocity(look.x * 1.6, 0.1, look.z * 1.6);
        p.velocityModified = true;
        p.fallDistance = 0;
    }

    // ---------- patterns ----------
    private static void line(ServerWorld w, PlayerEntity p, DemonType d, float dmg, int len, double width) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        for (double k = 1; k <= len; k += 0.35) {
            Vec3d c = eye.add(look.multiply(k));
            fx(w, main(d), c, 4, 0.2, 0.03);
            fx(w, ParticleTypes.DAMAGE_INDICATOR, c, 1, 0.05, 0);
        }
        for (LivingEntity t : targets(w, p, new Box(eye, eye.add(look.multiply(len))).expand(width))) hit(w, p, d, t, dmg, 0.5);
    }

    private static void ring(ServerWorld w, PlayerEntity p, DemonType d, float dmg, double radius, double kb) {
        Vec3d c = p.getEntityPos().add(0, 0.3, 0);
        for (double r = 1.2; r <= radius; r += 1.3) {
            int n = (int) (r * 8) + 12;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                fx(w, main(d), c.add(Math.cos(a) * r, (r / radius) * 0.6, Math.sin(a) * r), 2, 0.05, 0.02);
            }
        }
        for (LivingEntity t : targets(w, p, p.getBoundingBox().expand(radius, 1.5, radius))) hit(w, p, d, t, dmg, kb);
    }

    private static void launch(ServerWorld w, PlayerEntity p, DemonType d, float dmg) {
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        if (look.lengthSquared() > 1.0E-4) look = look.normalize();
        Vec3d c = p.getEntityPos().add(look.multiply(2.5));
        for (double y = 0; y < 6; y += 0.3) fx(w, main(d), c.add(0, y, 0), 6, 0.6, 0.04);
        for (LivingEntity t : targets(w, p, new Box(c.x - 3.5, c.y - 1, c.z - 3.5, c.x + 3.5, c.y + 4, c.z + 3.5))) {
            hit(w, p, d, t, dmg, 0.3);
            t.addVelocity(0, 1.0, 0);
            t.velocityModified = true;
        }
    }

    private static void ult(ServerWorld w, PlayerEntity p, DemonType d, float dmg, int radius) {
        sound(w, p, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f);
        sound(w, p, SoundEvents.ENTITY_WITHER_SPAWN, 1.3f);
        Vec3d c = p.getEntityPos().add(0, 0.2, 0);
        for (double r = 1; r <= radius; r += 1.2) {
            int n = (int) (r * 8) + 16;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                fx(w, main(d), c.add(Math.cos(a) * r, r * 0.2, Math.sin(a) * r), 2, 0.1, 0.05);
            }
        }
        for (double y = 0; y < 8; y += 0.4) fx(w, main(d), c.add(0, y, 0), 8, 0.5, 0.05);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, c.add(0, 1, 0), 1, 0, 0);
        for (LivingEntity t : targets(w, p, p.getBoundingBox().expand(radius, 2.5, radius))) hit(w, p, d, t, dmg, 1.6);
    }

    /** Troi buoc / lam cham / ngu: quai trong tam bi cham nang va yeu di. */
    private static void trap(ServerWorld w, PlayerEntity p, DemonType d, int radius) {
        Vec3d c = p.getEntityPos().add(0, 0.2, 0);
        for (int i = 0; i < 60; i++) {
            double a = i * Math.PI * 2 / 60;
            fx(w, main(d), c.add(Math.cos(a) * radius, 0.2, Math.sin(a) * radius), 2, 0.1, 0.02);
            fx(w, main(d), c.add(Math.cos(a) * radius * 0.5, 0.5, Math.sin(a) * radius * 0.5), 2, 0.1, 0.02);
        }
        for (LivingEntity t : targets(w, p, p.getBoundingBox().expand(radius, 2, radius))) {
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 6));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 2));
            t.damage(w, w.getDamageSources().playerAttack(p), 4.0f);
            fx(w, ParticleTypes.CRIMSON_SPORE, t.getEntityPos().add(0, 1, 0), 10, 0.3, 0.02);
        }
    }

    private static void blink(ServerWorld w, PlayerEntity p, DemonType d, int dist) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d pos = p.getEntityPos(), best = pos;
        for (double k = 1; k <= dist; k += 0.5) {
            Vec3d c = pos.add(look.multiply(k));
            if (!w.isAir(BlockPos.ofFloored(c.x, c.y, c.z)) || !w.isAir(BlockPos.ofFloored(c.x, c.y + 1, c.z))) break;
            best = c;
        }
        for (int i = 0; i < 25; i++) fx(w, main(d), pos.add(0, i * 0.08, 0), 3, 0.3, 0.05);
        p.requestTeleport(best.x, best.y, best.z);
        p.fallDistance = 0;
        for (int i = 0; i < 25; i++) fx(w, main(d), best.add(0, i * 0.08, 0), 3, 0.3, 0.05);
        sound(w, p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.8f);
    }

    private static void heal(ServerWorld w, PlayerEntity p, DemonType d) {
        p.setHealth(p.getMaxHealth());
        p.setFireTicks(0);
        p.removeStatusEffect(StatusEffects.WITHER);
        p.removeStatusEffect(StatusEffects.POISON);
        p.removeStatusEffect(StatusEffects.SLOWNESS);
        p.removeStatusEffect(StatusEffects.WEAKNESS);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 2));
        Vec3d c = p.getEntityPos();
        for (int i = 0; i < 40; i++) fx(w, ParticleTypes.HEART, c.add(Math.cos(i) * 0.8, i * 0.05, Math.sin(i) * 0.8), 1, 0.05, 0);
        sound(w, p, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.8f);
    }

    private static void pull(ServerWorld w, PlayerEntity p, DemonType d, float dmg, int radius) {
        Vec3d c = p.getEntityPos();
        for (double r = 1; r <= radius; r += 1.2) for (int i = 0; i < 24; i++) {
            double a = i * Math.PI / 12;
            fx(w, main(d), c.add(Math.cos(a) * r, 0.5, Math.sin(a) * r), 1, 0.05, 0.02);
        }
        for (LivingEntity t : targets(w, p, p.getBoundingBox().expand(radius, 2, radius))) {
            Vec3d v = p.getEntityPos().subtract(t.getEntityPos()).multiply(1, 0, 1);
            if (v.lengthSquared() > 1.0E-4) { v = v.normalize(); t.addVelocity(v.x * 1.4, 0.3, v.z * 1.4); t.velocityModified = true; }
            extra(d, t);
            t.damage(w, w.getDamageSources().playerAttack(p), dmg);
        }
    }
}
