package com.example.nichirin;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.List;

public class UtilDef {
    public static void reg(String id, UtilItem.Kind k, Rarity r, int max, Formatting col, String l1, String l2) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(Nichirin.ID, id));
        Item it = Registry.register(Registries.ITEM, key.getValue(), new UtilItem(new Item.Settings().registryKey(key).maxCount(max).rarity(r)
                .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal(l1).formatted(col, Formatting.BOLD),
                        Text.literal(l2).formatted(Formatting.GRAY)))), k));
        Nichirin.EXTRAS.add(it);
    }

    public static void register() {
        reg("wisteria_poison", UtilItem.Kind.WISTERIA, Rarity.UNCOMMON, 16, Formatting.LIGHT_PURPLE, "Doc Tu Dang", "Tan cong quy xung quanh bang doc");
        reg("spider_lily", UtilItem.Kind.LILY, Rarity.EPIC, 4, Formatting.AQUA, "Hoa Bi Ngan Xanh", "Quy khong con so anh nang");
        reg("slayer_mark", UtilItem.Kind.MARK, Rarity.EPIC, 1, Formatting.RED, "Dau An Sat Quy", "Tang suc manh 3 phut");
        reg("total_focus", UtilItem.Kind.FOCUS, Rarity.RARE, 1, Formatting.AQUA, "Toan Tap Trung Thuong Truc", "Tang toc do va hoi phuc 5 phut");
        reg("demon_summon", UtilItem.Kind.SUMMON, Rarity.UNCOMMON, 16, Formatting.RED, "Trieu Hoi Quy", "Chi Nichirin moi giet duoc quy");
        reg("demon_chosen", UtilItem.Kind.DEMON_CHOSEN, Rarity.EPIC, 16, Formatting.DARK_RED, "Triệu Hồi Quỷ Theo Menu", "Gọi quỷ bạn đã chọn trong menu (phím K)");
        reg("slayer_ally", UtilItem.Kind.ALLY, Rarity.RARE, 16, Formatting.AQUA, "Triệu Hồi Kiếm Sĩ", "Gọi đồng minh theo hơi thở đã chọn");
        reg("upper_demon_summon", UtilItem.Kind.UPPER, Rarity.EPIC, 4, Formatting.DARK_RED, "Trieu Hoi Thuong Huyen", "Quy cuc manh, can Nichirin de ha");
    }
}
