package com.example.nichirin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Thuc thi cac mau chieu. Chi gay sat thuong len quai hostile (khong anh huong PvP). */
public class Skills {

    public static void run(ServerWorld w, PlayerEntity p, Techniques.Tech t, double mult) {
        Breath b = t.breath();
        float dmg = (float) (t.damage() * mult);
        sound(w, p, soundOf(b), 1.0f);
        Fx.play(w, p, b, t.pattern(), t.range());
        switch (t.pattern()) {
            case SLASH -> line(w, p, b, dmg, t.range(), false, 1.3);
            case PIERCE -> line(w, p, b, dmg, t.range(), false, 0.9);
            case DASH -> { dash(p, b); line(w, p, b, dmg, t.range(), true, 1.5); }
            case RING -> ring(w, p, b, dmg, Math.min(8, t.range() * 1.2), 1.0);
            case LAUNCH -> launch(w, p, b, dmg);
            case ULT -> ultimate(w, p, b, dmg, t.range());
        }
        if (b == Breath.FLOWER || b == Breath.LOVE) p.heal(t.pattern() == Techniques.Pattern.ULT ? 8 : 2);
    }

    // ---------- helpers ----------
    private static SoundEvent soundOf(Breath b) {
        return switch (b) {
            case FIRE, SUN -> SoundEvents.ITEM_FIRECHARGE_USE;
            case WATER -> SoundEvents.ENTITY_PLAYER_SPLASH;
            case THUNDER -> SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER;
            case SOUND -> SoundEvents.BLOCK_NOTE_BLOCK_BELL.value();
            case LOVE, FLOWER -> SoundEvents.BLOCK_CHERRY_LEAVES_BREAK;
            case MOON -> SoundEvents.ENTITY_PLAYER_ATTACK_CRIT;
            default -> SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP;
        };
    }

    public static ParticleEffect main(Breath b) {
        return switch (b) {
            case FIRE, SUN -> ParticleTypes.FLAME;
            case WATER -> ParticleTypes.SPLASH;
            case THUNDER -> ParticleTypes.ELECTRIC_SPARK;
            case WIND -> ParticleTypes.CLOUD;
            case FLOWER -> ParticleTypes.CHERRY_LEAVES;
            case MIST -> ParticleTypes.POOF;
            case SERPENT -> ParticleTypes.SOUL;
            case SOUND -> ParticleTypes.NOTE;
            case LOVE -> ParticleTypes.HEART;
            case BEAST -> ParticleTypes.CRIT;
            case STONE -> ParticleTypes.ASH;
            case MOON -> ParticleTypes.END_ROD;
            case INSECT -> ParticleTypes.WITCH;
            case CLOUD -> ParticleTypes.CLOUD;
            case ICE -> ParticleTypes.SNOWFLAKE;
        };
    }

    private static void extra(Breath b, LivingEntity t) {
        switch (b) {
            case FIRE, SUN -> t.setFireTicks(120);
            case SOUND -> { t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 4)); t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 1)); }
            case MIST -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
            case SERPENT, INSECT -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 1));
            case MOON -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 0));
            case STONE -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
            case ICE -> { t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 4)); t.setFrozenTicks(140); }
            case CLOUD -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80, 0));
            default -> { }
        }
    }

    private static List<LivingEntity> demonsIn(ServerWorld w, PlayerEntity p, Box box) {
        return w.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive() && e instanceof Monster);
    }

    private static void hit(ServerWorld w, PlayerEntity p, Breath b, LivingEntity t, float dmg, double kb) {
        extra(b, t);
        t.damage(w, w.getDamageSources().playerAttack(p), dmg);
        Vec3d d = t.getEntityPos().subtract(p.getEntityPos()).multiply(1, 0, 1);
        if (d.lengthSquared() > 1.0E-4) {
            d = d.normalize();
            t.addVelocity(d.x * kb, 0.3, d.z * kb);

        }
    }

    private static void fx(ServerWorld w, ParticleEffect pe, Vec3d v, int n, double s, double sp) {
        w.spawnParticles(pe, v.x, v.y, v.z, n, s, s, s, sp);
    }

    private static void sound(ServerWorld w, PlayerEntity p, SoundEvent s, float pitch) {
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, 1.0f, pitch);
    }

    private static void dash(PlayerEntity p, Breath b) {
        Vec3d look = p.getRotationVec(1.0f);
        double v = b == Breath.THUNDER ? 2.6 : (b == Breath.WATER || b == Breath.BEAST ? 1.9 : 1.5);
        p.addVelocity(look.x * v, 0.1, look.z * v);

    }

    // ---------- patterns ----------
    private static void line(ServerWorld w, PlayerEntity p, Breath b, float dmg, int len, boolean dense, double width) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        for (double d = 1; d <= len; d += dense ? 0.3 : 0.4) {
            Vec3d c = eye.add(look.multiply(d));
            fx(w, main(b), c, dense ? 6 : 4, 0.25, 0.03);
            if (((int) (d * 2)) % 5 == 0) fx(w, ParticleTypes.SWEEP_ATTACK, c, 1, 0, 0);
        }
        for (LivingEntity t : demonsIn(w, p, new Box(eye, eye.add(look.multiply(len))).expand(width))) hit(w, p, b, t, dmg, 0.5);
    }

    private static void ring(ServerWorld w, PlayerEntity p, Breath b, float dmg, double radius, double kb) {
        Vec3d c = p.getEntityPos().add(0, 0.3, 0);
        for (double r = 1.2; r <= radius; r += 1.3) {
            int n = (int) (r * 8) + 12;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                fx(w, main(b), c.add(Math.cos(a) * r, (r / radius) * 0.6, Math.sin(a) * r), 2, 0.05, 0.02);
            }
        }
        double k = b == Breath.WIND ? kb * 1.7 : kb;
        for (LivingEntity t : demonsIn(w, p, p.getBoundingBox().expand(radius, 1.5, radius))) hit(w, p, b, t, dmg, k);
    }

    private static void launch(ServerWorld w, PlayerEntity p, Breath b, float dmg) {
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        if (look.lengthSquared() > 1.0E-4) look = look.normalize();
        Vec3d c = p.getEntityPos().add(look.multiply(2.5));
        for (double y = 0; y < 6; y += 0.3) fx(w, main(b), c.add(0, y, 0), 6, 0.6, 0.04);
        fx(w, ParticleTypes.EXPLOSION, c.add(0, 1, 0), 1, 0, 0);
        for (LivingEntity t : demonsIn(w, p, new Box(c.x - 3.5, c.y - 1, c.z - 3.5, c.x + 3.5, c.y + 4, c.z + 3.5))) {
            hit(w, p, b, t, dmg, 0.3);
            t.addVelocity(0, 1.0, 0);

        }
    }

    private static void ultimate(ServerWorld w, PlayerEntity p, Breath b, float dmg, int radius) {
        sound(w, p, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f);
        Vec3d c = p.getEntityPos().add(0, 0.2, 0);
        for (double r = 1; r <= radius; r += 1.2) {
            int n = (int) (r * 8) + 16;
            for (int i = 0; i < n; i++) {
                double a = i * Math.PI * 2 / n;
                Vec3d pos = c.add(Math.cos(a) * r, r * 0.2, Math.sin(a) * r);
                fx(w, main(b), pos, 2, 0.1, 0.05);
                if (i % 8 == 0) fx(w, ParticleTypes.FIREWORK, pos, 1, 0.1, 0.05);
            }
        }
        for (double y = 0; y < 8; y += 0.4) fx(w, main(b), c.add(0, y, 0), 8, 0.5, 0.05);
        fx(w, ParticleTypes.EXPLOSION_EMITTER, c.add(0, 1, 0), 1, 0, 0);
        double kb = b == Breath.WIND ? 2.5 : 1.4;
        for (LivingEntity t : demonsIn(w, p, p.getBoundingBox().expand(radius, 2.5, radius))) hit(w, p, b, t, dmg, kb);
    }
}
