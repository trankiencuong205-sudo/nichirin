package com.example.nichirin;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.List;

public class Nichirin implements ModInitializer {
    public static final String ID = "nichirin";
    public static final List<Item> BLADES = new ArrayList<>();

    private static Item blade(Breath b) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, b.id));
        Item.Settings s = new Item.Settings()
                .registryKey(key)
                .sword(ToolMaterial.NETHERITE, 4.0f, -2.2f)
                .rarity(Rarity.EPIC)
                .fireproof()
                .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal(b.title).formatted(b.color, Formatting.BOLD),
                        Text.literal(b.desc).formatted(Formatting.GRAY),
                        Text.literal(Techniques.of(b).size() + " thức").formatted(Formatting.GRAY),
                        Text.literal("Chuột phải: dùng thức | Shift+chuột phải: đổi thức | Phím K: mở menu").formatted(Formatting.DARK_GRAY, Formatting.ITALIC)
                )));
        Item item = Registry.register(Registries.ITEM, key.getValue(), new NichirinBlade(s, b));
        BLADES.add(item);
        return item;
    }

    public static final String DEMON_TAG = "nichirin_demon";
    public static final String ALLY_TAG = "nichirin_ally";
    public static final List<Item> EXTRAS = new ArrayList<>();
    public static Item DEMON_BLOOD;
    public static Item BLOOD_ART;

    private static void masterBlade() {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "master_blade"));
        Item it = Registry.register(Registries.ITEM, key.getValue(), new NichirinBlade(new Item.Settings()
                .registryKey(key).sword(ToolMaterial.NETHERITE, 5.0f, -2.2f).rarity(Rarity.EPIC).fireproof()
                .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal("Kiếm Nichirin Đa Hơi Thở").formatted(Formatting.WHITE, Formatting.BOLD),
                        Text.literal("Dùng hơi thở chọn trong menu (phím K)").formatted(Formatting.GRAY)))), null));
        BLADES.add(it);
    }

    @Override
    public void onInitialize() {
        RegistryKey<Item> dk = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "demon_blood"));
        DEMON_BLOOD = Registry.register(Registries.ITEM, dk.getValue(), new DemonBlood(new Item.Settings()
                .registryKey(dk).maxCount(16).rarity(Rarity.RARE)
                .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal("Hoa quy 10 phut").formatted(Formatting.DARK_RED, Formatting.BOLD),
                        Text.literal("Manh hon nhung bi anh nang thieu dot").formatted(Formatting.GRAY),
                        Text.literal("Chuot phai de uong").formatted(Formatting.DARK_GRAY, Formatting.ITALIC))))));
        RegistryKey<Item> bk = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "blood_art"));
        BLOOD_ART = Registry.register(Registries.ITEM, bk.getValue(), new BloodArt(new Item.Settings()
                .registryKey(bk).maxCount(1).rarity(Rarity.EPIC).fireproof()
                .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                        Text.literal("Huyet Quy Thuat").formatted(Formatting.DARK_RED, Formatting.BOLD),
                        Text.literal("20 quỷ, hàng trăm kỹ năng. Chỉ dùng khi đã hóa quỷ").formatted(Formatting.GRAY),
                        Text.literal("Phím K: chọn quỷ/kỹ năng | Shift+chuột phải: đổi").formatted(Formatting.DARK_GRAY, Formatting.ITALIC))))));
        Demon.register();
        PlayerData.register();
        Mobs.register();
        Net.register();
        masterBlade();
        UtilDef.register();
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!entity.getCommandTags().contains(DEMON_TAG)) return true;
            net.minecraft.entity.Entity a = source.getAttacker();
            if (a == null) return true; // anh nang, lua, doc, ...
            if (a instanceof net.minecraft.entity.LivingEntity le) return le.getCommandTags().contains(ALLY_TAG) || le.getMainHandStack().getItem() instanceof NichirinBlade;
            return false;
        });
        for (Breath b : Breath.values()) blade(b);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> { BLADES.forEach(e::add); e.add(DEMON_BLOOD); e.add(BLOOD_ART); EXTRAS.forEach(e::add); });
    }
}
