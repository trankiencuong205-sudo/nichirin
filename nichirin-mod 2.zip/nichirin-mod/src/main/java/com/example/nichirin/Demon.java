package com.example.nichirin;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Che do "thanh quy": manh hon nhung bi anh nang thieu dot. */
public class Demon {
    public static final int DURATION = 12000; // 10 phut
    private static final Map<UUID, Integer> DEMONS = new HashMap<>();

    private static final java.util.Set<UUID> IMMUNE = new java.util.HashSet<>();
    public static void sunImmune(UUID id) { IMMUNE.add(id); }

    public static boolean isDemon(UUID id) { return DEMONS.containsKey(id); }

    public static void become(ServerPlayerEntity p) {
        DEMONS.put(p.getUuid(), DURATION);
        p.sendMessage(Text.literal("Ban da hoa quy! Manh hon nhung so anh nang.").formatted(Formatting.DARK_RED, Formatting.BOLD), true);
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 10 != 0 || DEMONS.isEmpty()) return;
            for (ServerWorld w : server.getWorlds()) {
                for (ServerPlayerEntity p : w.getPlayers()) {
                    Integer left = DEMONS.get(p.getUuid());
                    if (left == null) continue;
                    if (!p.isAlive()) { DEMONS.remove(p.getUuid()); continue; }
                    left -= 10;
                    if (left <= 0) {
                        DEMONS.remove(p.getUuid());
                        p.sendMessage(Text.literal("Ban da tro lai lam nguoi.").formatted(Formatting.GREEN), true);
                        continue;
                    }
                    DEMONS.put(p.getUuid(), left);
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 1, false, false));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 0, false, false));
                    w.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.getX(), p.getY() + 1, p.getZ(), 6, 0.4, 0.8, 0.4, 0.02);
                    w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, p.getX(), p.getY() + 1.5, p.getZ(), 1, 0.2, 0.2, 0.2, 0.0);
                    if (!IMMUNE.contains(p.getUuid()) && w.isDay() && !w.isRaining() && w.isSkyVisible(p.getBlockPos())) {
                        p.setFireTicks(60);
                        p.sendMessage(Text.literal("Anh nang dang thieu dot ban!").formatted(Formatting.GOLD), true);
                    }
                }
            }
        });
    }
}
