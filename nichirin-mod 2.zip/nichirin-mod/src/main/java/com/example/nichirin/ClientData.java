package com.example.nichirin;

import java.util.HashMap;
import java.util.Map;

/** Ban sao du lieu nguoi choi o phia client (nhan tu server qua SyncPayload) de ve GUI. */
public class ClientData {
    public static int chosenBreath = 0, chosenDemon = 0, energy = 100;
    public static int[] sel = new int[Breath.values().length];
    public static int[] dsel = new int[DemonType.values().length];
    public static final Map<String, Integer> lvl = new HashMap<>();
    public static final Map<String, Integer> dlvl = new HashMap<>();
    public static Runnable listener;

    public static int level(int breath, int idx) { return lvl.getOrDefault(breath + "." + idx, 0); }
    public static int levelDemon(int demon, int idx) { return dlvl.getOrDefault(demon + "." + idx, 0); }

    public static void parse(String s) {
        lvl.clear(); dlvl.clear();
        for (String part : s.split(";")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            String k = part.substring(0, eq), v = part.substring(eq + 1);
            try {
                switch (k) {
                    case "br" -> chosenBreath = Integer.parseInt(v);
                    case "dm" -> chosenDemon = Integer.parseInt(v);
                    case "e" -> energy = Integer.parseInt(v);
                    case "sel" -> pairs(v, sel);
                    case "dsel" -> pairs(v, dsel);
                    case "lvl" -> levels(v, lvl);
                    case "dlvl" -> levels(v, dlvl);
                    default -> { }
                }
            } catch (Exception ignored) { }
        }
        if (listener != null) listener.run();
    }

    private static void pairs(String v, int[] out) {
        for (String e : v.split(",")) {
            String[] a = e.split(":");
            if (a.length == 2) { int i = Integer.parseInt(a[0]); if (i >= 0 && i < out.length) out[i] = Integer.parseInt(a[1]); }
        }
    }

    private static void levels(String v, Map<String, Integer> out) {
        for (String e : v.split(",")) {
            String[] a = e.split(":");
            if (a.length == 2) out.put(a[0], Integer.parseInt(a[1]));
        }
    }
}
