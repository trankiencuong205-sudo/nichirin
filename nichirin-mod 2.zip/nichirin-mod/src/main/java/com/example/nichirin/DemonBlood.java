package com.example.nichirin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class DemonBlood extends Item {
    public DemonBlood(Settings settings) { super(settings); }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world.isClient() || !(user instanceof ServerPlayerEntity sp)) return ActionResult.SUCCESS;
        if (Demon.isDemon(sp.getUuid())) return ActionResult.FAIL;
        Demon.become(sp);
        world.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 0.6f, 1.6f);
        if (!sp.isCreative()) user.getStackInHand(hand).decrement(1);
        return ActionResult.SUCCESS;
    }
}
