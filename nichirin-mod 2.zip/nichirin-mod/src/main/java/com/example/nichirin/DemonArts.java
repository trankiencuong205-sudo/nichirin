package com.example.nichirin;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Huyet Quy Thuat cua tung quy. canon=false: ten mo ta / Custom Skill do mod dat, khong phai ten chinh thuc. */
public class DemonArts {
    public enum Pattern { SLASH, RING, DASH, LAUNCH, PIERCE, ULT, TRAP, BLINK, HEAL, PULL }

    public record Art(DemonType demon, int num, String name, boolean canon, Pattern pattern,
                      float damage, int range, int cooldown, int energy) {}

    private static final Map<DemonType, List<Art>> MAP = new EnumMap<>(DemonType.class);

    public static List<Art> of(DemonType d) { return MAP.get(d); }

    private static void add(DemonType d, int num, String name, boolean canon, Pattern p, float dmg, int range, int cd, int energy) {
        MAP.computeIfAbsent(d, k -> new ArrayList<>()).add(new Art(d, num, name, canon, p, dmg, range, cd, energy));
    }

    static {
        add(DemonType.KOKUSHIBO, 1, "Nguyệt Hoa Đột", true, Pattern.PIERCE, 9.0f, 12, 40, 10);
        add(DemonType.KOKUSHIBO, 2, "Ám Nguyệt — Cung Điện", true, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.KOKUSHIBO, 3, "Châu Hoa Lộng Nguyệt", true, Pattern.DASH, 10.2f, 9, 48, 16);
        add(DemonType.KOKUSHIBO, 4, "Yểm Nguyệt — Tiêu Đầu Vũ", true, Pattern.LAUNCH, 10.8f, 4, 52, 19);
        add(DemonType.KOKUSHIBO, 5, "Nguyệt Hồn — Tai Tai Nguyệt", true, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.KOKUSHIBO, 6, "Thường Dạ Cô Nguyệt — Vô Gian", true, Pattern.SLASH, 12.0f, 6, 60, 10);
        add(DemonType.KOKUSHIBO, 7, "Nguyệt Hồng — Thiên Địa", true, Pattern.RING, 12.6f, 5, 40, 13);
        add(DemonType.KOKUSHIBO, 8, "Khuyết Nguyệt — Viễn Lâu", true, Pattern.DASH, 13.2f, 9, 44, 16);
        add(DemonType.KOKUSHIBO, 9, "Vô Khuyết Nguyệt", true, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.DOMA, 1, "Liên Hoa Băng", true, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.DOMA, 2, "Bạch Cơ Tuyết", true, Pattern.PIERCE, 9.6f, 12, 44, 13);
        add(DemonType.DOMA, 3, "Băng Trụ", true, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.DOMA, 4, "Tán Liên Hoa", true, Pattern.HEAL, 0.0f, 0, 200, 25);
        add(DemonType.DOMA, 5, "Băng Nhân", true, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.DOMA, 6, "Ngự Tử Tượng", true, Pattern.SLASH, 12.0f, 6, 60, 10);
        add(DemonType.DOMA, 7, "Hàn Liệt Chi Bạch Cơ", true, Pattern.RING, 12.6f, 5, 40, 13);
        add(DemonType.DOMA, 8, "Băng Lam Thủy Liên Bồ Tát", true, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.AKAZA, 1, "La Châm", true, Pattern.PIERCE, 9.0f, 12, 40, 10);
        add(DemonType.AKAZA, 2, "Phá Phôi Sát: Không Thức", true, Pattern.PIERCE, 9.6f, 12, 44, 13);
        add(DemonType.AKAZA, 3, "Phá Phôi Sát: Loạn Thức", true, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.AKAZA, 4, "Phá Phôi Sát: Diệt Thức", true, Pattern.PIERCE, 10.8f, 12, 52, 19);
        add(DemonType.AKAZA, 5, "Phá Phôi Sát: Cước Thức — Lưu Quang Quần Quang", true, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.AKAZA, 6, "Phá Phôi Sát: Cước Thức — Phi Lưu Tinh Thiên Luân", true, Pattern.RING, 12.0f, 5, 60, 10);
        add(DemonType.AKAZA, 7, "Phá Phôi Sát: Cước Thức — Bạo Liệt Hồng Kính", true, Pattern.RING, 12.6f, 5, 40, 13);
        add(DemonType.AKAZA, 8, "Phá Phôi Sát: Cước Thức — Thanh Ngân Loạn Tàn Quang", true, Pattern.PIERCE, 13.2f, 12, 44, 16);
        add(DemonType.AKAZA, 9, "Phá Phôi Sát: Chung Thức — Thanh Ngân Loạn Tàn Quang", true, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.HANTENGU, 1, "Sekido: Sấm sét", false, Pattern.SLASH, 9.0f, 6, 40, 10);
        add(DemonType.HANTENGU, 2, "Karaku: Gió từ quạt", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.HANTENGU, 3, "Aizetsu: Thương kích", false, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.HANTENGU, 4, "Urogi: Sóng âm và khả năng bay", false, Pattern.LAUNCH, 10.8f, 4, 52, 19);
        add(DemonType.HANTENGU, 5, "Zohakuten: Mộc Long", false, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.HANTENGU, 6, "Mộc Long Công Kích", false, Pattern.PIERCE, 12.0f, 12, 60, 10);
        add(DemonType.HANTENGU, 7, "Mộc Long Triệu Hồi", false, Pattern.RING, 12.6f, 5, 40, 13);
        add(DemonType.HANTENGU, 8, "Lôi Kích", false, Pattern.PIERCE, 13.2f, 12, 44, 16);
        add(DemonType.HANTENGU, 9, "Sóng Âm", false, Pattern.LAUNCH, 13.8f, 4, 48, 19);
        add(DemonType.HANTENGU, 10, "Hợp Nhất Cảm Xúc", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.GYOKKO, 1, "Bình Cá", false, Pattern.TRAP, 9.0f, 6, 40, 10);
        add(DemonType.GYOKKO, 2, "Thủy Lao", false, Pattern.TRAP, 9.6f, 6, 44, 13);
        add(DemonType.GYOKKO, 3, "Cá Quỷ Triệu Hồi", false, Pattern.DASH, 10.2f, 9, 48, 16);
        add(DemonType.GYOKKO, 4, "Sát Ngư Lân", false, Pattern.PIERCE, 10.8f, 12, 52, 19);
        add(DemonType.GYOKKO, 5, "Vạn Ngư Huyết Sát", false, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.GYOKKO, 6, "Chân Thân Biến Hình", false, Pattern.HEAL, 0.0f, 0, 200, 25);
        add(DemonType.GYOKKO, 7, "Chạm Hóa Ngọc", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.GYUTARO, 1, "Huyết Toàn Luân", false, Pattern.RING, 9.0f, 5, 40, 10);
        add(DemonType.GYUTARO, 2, "Phi Huyết Liêm", false, Pattern.DASH, 9.6f, 9, 44, 13);
        add(DemonType.GYUTARO, 3, "Huyết Độc Trảm", false, Pattern.DASH, 10.2f, 9, 48, 16);
        add(DemonType.GYUTARO, 4, "Huyết Liêm Liên Trảm", false, Pattern.DASH, 10.8f, 9, 52, 19);
        add(DemonType.GYUTARO, 5, "Huyết Toàn Luân Liên Hoàn", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.DAKI, 1, "Bát Trọng Đai Trảm", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.DAKI, 2, "Đai Lưng Trói Buộc", false, Pattern.TRAP, 9.6f, 6, 44, 13);
        add(DemonType.DAKI, 3, "Đai Lưng Trảm Kích", false, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.DAKI, 4, "Phi Đái Trảm", false, Pattern.DASH, 10.8f, 9, 52, 19);
        add(DemonType.DAKI, 5, "Đai Lưng Phòng Thủ", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.NAKIME, 1, "Biwa: Thay Đổi Không Gian", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.NAKIME, 2, "Dịch Chuyển Phòng", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.NAKIME, 3, "Đảo Lộn Địa Hình", false, Pattern.RING, 10.2f, 5, 48, 16);
        add(DemonType.NAKIME, 4, "Triệu Hồi Cửa", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.NAKIME, 5, "Điều Khiển Vô Hạn Thành", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.KAIGAKU, 1, "Lôi Kích", false, Pattern.PIERCE, 9.0f, 12, 40, 10);
        add(DemonType.KAIGAKU, 2, "Hắc Lôi Trảm", false, Pattern.DASH, 9.6f, 9, 44, 13);
        add(DemonType.KAIGAKU, 3, "Lôi Điện Liên Trảm", false, Pattern.DASH, 10.2f, 9, 48, 16);
        add(DemonType.KAIGAKU, 4, "Hắc Lôi Bộc Phát", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.ENMU, 1, "Thôi Miên", false, Pattern.TRAP, 9.0f, 6, 40, 10);
        add(DemonType.ENMU, 2, "Dẫn Dắt Giấc Mơ", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.ENMU, 3, "Ác Mộng", false, Pattern.TRAP, 10.2f, 6, 48, 16);
        add(DemonType.ENMU, 4, "Đưa Mục Tiêu Vào Giấc Ngủ", false, Pattern.TRAP, 10.8f, 6, 52, 19);
        add(DemonType.ENMU, 5, "Hợp Nhất Với Tàu", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.ENMU, 6, "Xúc Tu Tấn Công", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.RUI, 1, "Tơ Nhện Trảm", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.RUI, 2, "Tơ Nhện Phòng Thủ", false, Pattern.TRAP, 9.6f, 6, 44, 13);
        add(DemonType.RUI, 3, "Tơ Nhện Trói Buộc", false, Pattern.TRAP, 10.2f, 6, 48, 16);
        add(DemonType.RUI, 4, "Tơ Nhện Xoay", false, Pattern.PULL, 10.8f, 8, 52, 19);
        add(DemonType.RUI, 5, "Tơ Nhện Sát Thương", false, Pattern.PIERCE, 11.4f, 12, 56, 22);
        add(DemonType.RUI, 6, "Tơ Nhện Cắt Chém", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.MUZAN, 1, "Roi Thịt", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.MUZAN, 2, "Xúc Tu Thịt", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.MUZAN, 3, "Miệng Cắn", false, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.MUZAN, 4, "Biến Đổi Cơ Thể", false, Pattern.HEAL, 0.0f, 0, 200, 25);
        add(DemonType.MUZAN, 5, "Phân Tách Cơ Thể", false, Pattern.HEAL, 0.0f, 0, 200, 25);
        add(DemonType.MUZAN, 6, "Hồi Phục Tối Cao", false, Pattern.HEAL, 0.0f, 0, 200, 25);
        add(DemonType.MUZAN, 7, "Hình Thái Chiến Đấu", false, Pattern.RING, 12.6f, 5, 40, 13);
        add(DemonType.MUZAN, 8, "Tấn Công Diện Rộng", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.NEZUKO, 1, "Huyết Quỷ Bộc Huyết", false, Pattern.SLASH, 9.0f, 6, 40, 10);
        add(DemonType.NEZUKO, 2, "Huyết Diễm", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.NEZUKO, 3, "Hỏa Diễm Huyết Quỷ", false, Pattern.DASH, 10.2f, 9, 48, 16);
        add(DemonType.NEZUKO, 4, "Huyết Diễm Thiêu Đốt", false, Pattern.LAUNCH, 10.8f, 4, 52, 19);
        add(DemonType.NEZUKO, 5, "Cường Hóa Hình Thái Quỷ", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.SUSAMARU, 1, "Temari Liên Hoàn", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.SUSAMARU, 2, "Temari Truy Kích", false, Pattern.PIERCE, 9.6f, 12, 44, 13);
        add(DemonType.SUSAMARU, 3, "Temari Nảy Bật", false, Pattern.LAUNCH, 10.2f, 4, 48, 16);
        add(DemonType.SUSAMARU, 4, "Temari Oanh Kích", false, Pattern.RING, 10.8f, 5, 52, 19);
        add(DemonType.SUSAMARU, 5, "Temari Bạo Phát", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.YAHABA, 1, "Mũi Tên Điều Hướng", false, Pattern.PIERCE, 9.0f, 12, 40, 10);
        add(DemonType.YAHABA, 2, "Đẩy Mục Tiêu", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.YAHABA, 3, "Kéo Mục Tiêu", false, Pattern.PULL, 10.2f, 8, 48, 16);
        add(DemonType.YAHABA, 4, "Đổi Hướng Vật Thể", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.YAHABA, 5, "Điều Khiển Quỹ Đạo", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.KYOGAI, 1, "Trống Xoay Phòng", false, Pattern.RING, 9.0f, 5, 40, 10);
        add(DemonType.KYOGAI, 2, "Trống Chém", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.KYOGAI, 3, "Trống Đẩy Lùi", false, Pattern.RING, 10.2f, 5, 48, 16);
        add(DemonType.KYOGAI, 4, "Trống Thay Đổi Hướng", false, Pattern.BLINK, 0.0f, 10, 60, 15);
        add(DemonType.KYOGAI, 5, "Trống Liên Hoàn", false, Pattern.ULT, 26.0f, 8, 300, 55);
        add(DemonType.WAKURABA, 1, "Custom: Vuốt Quỷ", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.WAKURABA, 2, "Custom: Huyết Nhận", false, Pattern.DASH, 9.6f, 9, 44, 13);
        add(DemonType.MUKAGO, 1, "Custom: Móng Độc", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.MUKAGO, 2, "Custom: Bóng Tối", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.ROKURO, 1, "Custom: Cú Đấm Quỷ", false, Pattern.DASH, 9.0f, 9, 40, 10);
        add(DemonType.ROKURO, 2, "Custom: Huyết Chấn", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.KYOKO, 1, "Custom: Huyết Trảo", false, Pattern.SLASH, 9.0f, 6, 40, 10);
        add(DemonType.KYOKO, 2, "Custom: Huyết Bạo", false, Pattern.RING, 9.6f, 5, 44, 13);
        add(DemonType.KYOKO, 3, "Custom: Huyết Tia", false, Pattern.PIERCE, 10.2f, 12, 48, 16);
        add(DemonType.KYOKO, 4, "Custom: Huyết Hải Vực", false, Pattern.ULT, 26.0f, 8, 300, 55);
    }
}
