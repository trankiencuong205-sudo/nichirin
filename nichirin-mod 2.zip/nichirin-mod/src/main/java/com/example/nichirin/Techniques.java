package com.example.nichirin;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Danh sach thuc cua tung Hoi Tho. canon=false nghia la Custom Skill (mod tu sang tao). */
public class Techniques {
    public enum Pattern { SLASH, RING, DASH, LAUNCH, PIERCE, ULT }

    public record Tech(Breath breath, int num, String vn, String en, boolean canon, Pattern pattern,
                       float damage, int range, int cooldown, int energy) {}

    private static final Map<Breath, List<Tech>> MAP = new EnumMap<>(Breath.class);

    public static List<Tech> of(Breath b) { return MAP.get(b); }

    private static void add(Breath b, int num, String vn, String en, boolean canon, Pattern p, float dmg, int range, int cd, int energy) {
        MAP.computeIfAbsent(b, k -> new ArrayList<>()).add(new Tech(b, num, vn, en, canon, p, dmg, range, cd, energy));
    }

    static {
        add(Breath.SUN, 1, "Viên Vũ", "Dance", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.SUN, 2, "Bích La Thiên", "Clear Blue Sky", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.SUN, 3, "Liệt Nhật Hồng Kính", "Raging Sun", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.SUN, 4, "Huyễn Nhật Hồng", "Burning Bones, Summer Sun", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.SUN, 5, "Hỏa Xa", "Fire Wheel", true, Pattern.RING, 10.0f, 5, 42, 20);
        add(Breath.SUN, 6, "Dương Hoa Đột", "Solar Heat Haze", true, Pattern.SLASH, 10.5f, 6, 45, 8);
        add(Breath.SUN, 7, "Nhật Vận Chi Long — Vũ Điệu Huyễn Ảnh", "Setting Sun Transformation", true, Pattern.RING, 11.0f, 5, 30, 11);
        add(Breath.SUN, 8, "Phiên Viêm", "Beneficent Radiance", true, Pattern.DASH, 11.5f, 9, 33, 14);
        add(Breath.SUN, 9, "Hỏa Hồng", "Sunflower Thrust", true, Pattern.PIERCE, 12.0f, 12, 36, 17);
        add(Breath.SUN, 10, "Phác Liệt Nhật", "Sun Halo Dragon Head Dance", true, Pattern.RING, 12.5f, 5, 39, 20);
        add(Breath.SUN, 11, "Nhật Hồn", "Sun Shadow", true, Pattern.SLASH, 13.0f, 6, 42, 8);
        add(Breath.SUN, 12, "Viên Vũ Nhất Thiểm", "Fake Rainbow", true, Pattern.RING, 13.5f, 5, 45, 11);
        add(Breath.SUN, 13, "Chuỗi 12 thức liên hoàn", "Constant Combo of 12 Forms", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.MOON, 1, "Ám Nguyệt — Cung Điện", "Dark Moon, Evening Palace", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.MOON, 2, "Châu Hoa Lộng Nguyệt", "Pearl Flower Moongazing", true, Pattern.DASH, 8.5f, 9, 33, 11);
        add(Breath.MOON, 3, "Yểm Nguyệt — Tiêu Đầu Vũ", "Loathsome Moon, Chains", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.MOON, 4, "Hắc Nguyệt — Phán Phán Nguyệt", "Moon Spirit Calamitous Eddy", true, Pattern.RING, 9.5f, 5, 39, 17);
        add(Breath.MOON, 5, "Nguyệt Hồn — Tai Tai Nguyệt", "Moon-Dragon Ringtail", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.MOON, 6, "Thường Dạ Cô Nguyệt — Vô Gian", "Perpetual Night, Lonely Moon - Incessant", true, Pattern.SLASH, 10.5f, 6, 45, 8);
        add(Breath.MOON, 7, "Yểm Kính — Nguyệt Ánh", "Mirror of Misfortune, Moonlit", true, Pattern.RING, 11.0f, 5, 30, 11);
        add(Breath.MOON, 8, "Nguyệt Long Luân Vĩ", "Moon-Dragon Ringtail", true, Pattern.DASH, 11.5f, 9, 33, 14);
        add(Breath.MOON, 9, "Khuyết Nguyệt — Viễn Lâu", "Waning Moonswaths", true, Pattern.LAUNCH, 12.0f, 4, 36, 17);
        add(Breath.MOON, 10, "Xuyên Diện — Nguyệt Cảnh", "Drilling Slashes, Moon Through Bamboo Leaves", true, Pattern.PIERCE, 12.5f, 12, 39, 20);
        add(Breath.MOON, 11, "Ám Nguyệt — Tiêu Đầu Vũ", "Dark Moon, Evening Palace", true, Pattern.SLASH, 13.0f, 6, 42, 8);
        add(Breath.MOON, 12, "Nguyệt Hồng — Thiên Địa", "Moonbow, Half Moon", true, Pattern.RING, 13.5f, 5, 45, 11);
        add(Breath.MOON, 13, "Nguyệt Bạch Tai Tai", "Moonbow, Half Moon", true, Pattern.DASH, 14.0f, 9, 30, 14);
        add(Breath.MOON, 14, "Hung Nguyệt — Tiêu Vĩ", "Catastrophe, Tenman Crescent Moon", true, Pattern.LAUNCH, 14.5f, 4, 33, 17);
        add(Breath.MOON, 15, "Viên Nguyệt — Tiêu Vĩ", "Full Moon, Tenman Crescent Moon", true, Pattern.PIERCE, 15.0f, 12, 36, 20);
        add(Breath.MOON, 16, "Vô Khuyết Nguyệt", "Moonless", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.WATER, 1, "Thủy Diện Trảm", "Water Surface Slash", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.WATER, 2, "Thủy Xa", "Water Wheel", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.WATER, 3, "Lưu Lưu Vũ", "Flowing Dance", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.WATER, 4, "Đả Triều", "Striking Tide", true, Pattern.DASH, 9.5f, 9, 39, 17);
        add(Breath.WATER, 5, "Cam Vũ", "Blessed Rain After the Drought", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.WATER, 6, "Nữu Chuyển Tuyền Qua", "Whirlpool", true, Pattern.RING, 10.5f, 5, 45, 8);
        add(Breath.WATER, 7, "Giọt Nước Xuyên Đá", "Drop Ripple Thrust", true, Pattern.PIERCE, 11.0f, 12, 30, 11);
        add(Breath.WATER, 8, "Thác Nước Chậu", "Waterfall Basin", true, Pattern.LAUNCH, 11.5f, 4, 33, 14);
        add(Breath.WATER, 9, "Thủy Lưu Phi Mạt", "Splashing Water Flow, Turbulent", true, Pattern.DASH, 12.0f, 9, 36, 17);
        add(Breath.WATER, 10, "Sinh Sinh Lưu Chuyển", "Constant Flux", true, Pattern.DASH, 12.5f, 9, 39, 20);
        add(Breath.WATER, 11, "Tĩnh Lặng", "Dead Calm", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.FIRE, 1, "Bất Tri Hỏa", "Unknowing Fire", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.FIRE, 2, "Thăng Viêm Thiên", "Rising Scorching Sun", true, Pattern.LAUNCH, 8.5f, 4, 33, 11);
        add(Breath.FIRE, 3, "Khí Viêm Vạn Tượng", "Blazing Universe", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.FIRE, 4, "Thịnh Viêm Hải Triều", "Blooming Flame Undulation", true, Pattern.RING, 9.5f, 5, 39, 17);
        add(Breath.FIRE, 5, "Viêm Hổ", "Flame Tiger", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.FIRE, 6, "Luyện Ngục", "Rengoku", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.THUNDER, 1, "Phích Lịch Nhất Thiểm", "Thunderclap and Flash", true, Pattern.DASH, 8.0f, 9, 30, 8);
        add(Breath.THUNDER, 2, "Đạo Hồn", "Rice Spirit", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.THUNDER, 3, "Tụ Văn Thành Lôi", "Thunder Swarm", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.THUNDER, 4, "Viễn Lôi", "Distant Thunder", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.THUNDER, 5, "Nhiệt Giới Lôi", "Heat Lightning", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.THUNDER, 6, "Điện Oanh Lôi Oanh", "Rumble and Flash", true, Pattern.DASH, 10.5f, 9, 45, 8);
        add(Breath.THUNDER, 7, "Hỏa Lôi Thần", "Flaming Thunder God", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.WIND, 1, "Trần Toàn Phong", "Dust Whirlwind Cutter", true, Pattern.RING, 8.0f, 5, 30, 8);
        add(Breath.WIND, 2, "Trảo Trảo Khoa Hộ Phong", "Claws-Purifying Wind", true, Pattern.PIERCE, 8.5f, 12, 33, 11);
        add(Breath.WIND, 3, "Thanh Lam Phong Thụ", "Clean Storm Wind Tree", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.WIND, 4, "Thăng Thượng Sa Trần Lam", "Rising Dust Storm", true, Pattern.RING, 9.5f, 5, 39, 17);
        add(Breath.WIND, 5, "Cuồng Phong Yên Lam", "Cold Mountain Wind", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.WIND, 6, "Hắc Phong Yên Lam", "Black Wind Mountain Mist", true, Pattern.RING, 10.5f, 5, 45, 8);
        add(Breath.WIND, 7, "Cương Phong Phủ", "Gale, Sudden Gusts", true, Pattern.RING, 11.0f, 5, 30, 11);
        add(Breath.WIND, 8, "Sơ Liệt Phong Trảm", "Primary Gale Slash", true, Pattern.DASH, 11.5f, 9, 33, 14);
        add(Breath.WIND, 9, "Vận Vận Lam", "Idaten Typhoon", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.STONE, 1, "Xà Văn Nham", "Serpentinite Bipolar", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.STONE, 2, "Thiên Diện Toái", "Upper Smash", true, Pattern.LAUNCH, 8.5f, 4, 33, 11);
        add(Breath.STONE, 3, "Nham Khuất", "Stone Skin", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.STONE, 4, "Lưu Văn Nham", "Volcanic Rock, Rapid Conquest", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.STONE, 5, "Ngõa Luân Hình Bộ", "Arcs of Justice", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.MIST, 1, "Vân Tiêu", "Low Clouds, Distant Haze", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.MIST, 2, "Bát Trọng Hà", "Eight-Layered Mist", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.MIST, 3, "Lưu Lưu Vũ", "Scattering Mist Splash", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.MIST, 4, "Bình Lưu", "Shifting Flow Slash", true, Pattern.DASH, 9.5f, 9, 39, 17);
        add(Breath.MIST, 5, "Hà Vân Hải", "Sea of Clouds and Haze", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.MIST, 6, "Nguyệt Hà Tiêu", "Lunar Dispersing Mist", true, Pattern.RING, 10.5f, 5, 45, 8);
        add(Breath.MIST, 7, "Mê Vụ", "Obscuring Clouds", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.SOUND, 1, "Oanh", "Roar", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.SOUND, 2, "Hưởng Trảm Vô Gian", "Constant Resounding Slashes", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.SOUND, 3, "Minh Huyền Tào Tào", "String Performance", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.LOVE, 1, "Sơ Luyến Chiến Tranh", "Shivers of First Love", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.LOVE, 2, "Não Đầu Hồng Diệp", "Love Pangs", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.LOVE, 3, "Luyến Miêu Thời Vũ", "Catlove Shower", true, Pattern.RING, 9.0f, 5, 36, 14);
        add(Breath.LOVE, 4, "Phác Lạc Thứ Vạn Liên", "Swaying Love, Wildclaw", true, Pattern.PIERCE, 9.5f, 12, 39, 17);
        add(Breath.LOVE, 5, "Diêu Chuyển Liệt Hoa", "Swaying Love, Wildclaw", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.LOVE, 6, "Miêu Túc Luyến Phong", "Cat-Legged Winds of Love", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.SERPENT, 1, "Xà Vân", "Winding Serpent Slash", true, Pattern.SLASH, 8.0f, 6, 30, 8);
        add(Breath.SERPENT, 2, "Độc Nha", "Venom Fangs of the Narrow Head", true, Pattern.PIERCE, 8.5f, 12, 33, 11);
        add(Breath.SERPENT, 3, "Uốn Khúc", "Coil Choke", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.SERPENT, 4, "Liệt Trảm", "Twin-Headed Reptile", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.SERPENT, 5, "Xà Xoay", "Slithering Serpent", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.FLOWER, 1, "Điệu Vũ Hoa", "Flower Dance", true, Pattern.DASH, 8.0f, 9, 30, 8);
        add(Breath.FLOWER, 2, "Ngự Ảnh Mai", "Honorable Shadow Plum", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.FLOWER, 3, "Hoa Vũ Cuồng Phong", "Custom Skill", false, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.FLOWER, 4, "Hồng Hoa Y", "Crimson Hanagoromo", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.FLOWER, 5, "Quả Báo Hoa", "Peonies of Futility", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.FLOWER, 6, "Xoáy Đào", "Whirling Peach", true, Pattern.RING, 10.5f, 5, 45, 8);
        add(Breath.FLOWER, 7, "Bỉ Ngạn Chu Nhãn", "Equinoctial Vermilion Eye", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.INSECT, 1, "Điệp Vũ — Du Hý", "Butterfly Dance: Caprice", true, Pattern.DASH, 8.0f, 9, 30, 8);
        add(Breath.INSECT, 2, "Phong Vũ Châm — Chân Mỹ", "Dance of the Bee Sting: True Flutter", true, Pattern.PIERCE, 8.5f, 12, 33, 11);
        add(Breath.INSECT, 3, "Phục Vũ — Phục Huyễn", "Dance of the Dragonfly: Compound Eye Hexagon", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.INSECT, 4, "Ngô Công Vũ", "Dance of the Centipede: Hundred-Legged Zigzag", true, Pattern.ULT, 24.0f, 8, 300, 50);
        add(Breath.BEAST, 1, "Nanh Xuyên Thấu", "Pierce", true, Pattern.PIERCE, 8.0f, 12, 30, 8);
        add(Breath.BEAST, 2, "Nanh Xé Toạc", "Rip and Tear", true, Pattern.RING, 8.5f, 5, 33, 11);
        add(Breath.BEAST, 3, "Nanh Nuốt Chửng", "Devour", true, Pattern.DASH, 9.0f, 9, 36, 14);
        add(Breath.BEAST, 4, "Nanh Cắt Thành Dải", "Slice 'n' Dice", true, Pattern.LAUNCH, 9.5f, 4, 39, 17);
        add(Breath.BEAST, 5, "Nanh Cuồng Loạn", "Crazy Cutting", true, Pattern.PIERCE, 10.0f, 12, 42, 20);
        add(Breath.BEAST, 6, "Nanh Cắn Xé", "Palate Joint", true, Pattern.SLASH, 10.5f, 6, 45, 8);
        add(Breath.BEAST, 7, "Nhận Biết Không Gian", "Spatial Awareness", true, Pattern.RING, 11.0f, 5, 30, 11);
        add(Breath.BEAST, 8, "Lao Nhanh", "Explosive Rush", true, Pattern.DASH, 11.5f, 9, 33, 14);
        add(Breath.BEAST, 9, "Cắt Xoáy", "Extending Bendy Slash", true, Pattern.LAUNCH, 12.0f, 4, 36, 17);
        add(Breath.BEAST, 10, "Răng Cưa", "Whirling Fangs", true, Pattern.ULT, 24.0f, 8, 300, 50);
    }
}
