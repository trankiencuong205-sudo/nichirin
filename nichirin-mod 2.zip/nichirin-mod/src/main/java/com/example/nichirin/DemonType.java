package com.example.nichirin;

import net.minecraft.util.Formatting;

public enum DemonType {
    KOKUSHIBO("Kokushibo — Thượng Huyền Nhất", "Kiếm quỷ và trảm kích Mặt Trăng", Formatting.DARK_PURPLE, true),
    DOMA("Doma — Thượng Huyền Nhị", "Băng", Formatting.AQUA, true),
    AKAZA("Akaza — Thượng Huyền Tam", "La Châm", Formatting.LIGHT_PURPLE, true),
    HANTENGU("Hantengu — Thượng Huyền Tứ", "Phân thân cảm xúc", Formatting.YELLOW, false),
    GYOKKO("Gyokko — Thượng Huyền Ngũ", "Bình gốm và sinh vật thủy sinh", Formatting.DARK_AQUA, false),
    GYUTARO("Gyutaro — Thượng Huyền Lục", "Huyết liêm", Formatting.DARK_RED, false),
    DAKI("Daki — Thượng Huyền Lục", "Đai lưng Obi", Formatting.RED, false),
    NAKIME("Nakime", "Điều khiển Vô Hạn Thành", Formatting.GOLD, false),
    KAIGAKU("Kaigaku", "Huyết Quỷ Thuật kết hợp kiếm thuật Sấm Sét", Formatting.YELLOW, false),
    ENMU("Enmu — Hạ Huyền Nhất", "Giấc mơ", Formatting.DARK_GREEN, false),
    RUI("Rui — Hạ Huyền Ngũ", "Tơ nhện", Formatting.WHITE, false),
    MUZAN("Muzan Kibutsuji", "Biến đổi cơ thể", Formatting.DARK_RED, false),
    NEZUKO("Nezuko Kamado", "Huyết quỷ bộc huyết", Formatting.LIGHT_PURPLE, false),
    SUSAMARU("Susamaru", "Temari", Formatting.GREEN, false),
    YAHABA("Yahaba", "Mũi tên", Formatting.GRAY, false),
    KYOGAI("Kyogai", "Trống", Formatting.GOLD, false),
    WAKURABA("Wakuraba — Hạ Huyền Tam", "Chưa được tiết lộ tên chính thức (Custom Skill)", Formatting.DARK_GRAY, false),
    MUKAGO("Mukago — Hạ Huyền Tứ", "Chưa được tiết lộ tên chính thức (Custom Skill)", Formatting.DARK_GRAY, false),
    ROKURO("Rokuro — Hạ Huyền Nhị", "Chưa được tiết lộ tên chính thức (Custom Skill)", Formatting.DARK_GRAY, false),
    KYOKO("Kyoko và các quỷ khác", "Kỹ năng tùy chỉnh (Custom Skill)", Formatting.DARK_GRAY, false);

    public final String title, tag;
    public final Formatting color;
    /** true = ten ky nang bam sat nguyen tac; false = ten mo ta/Custom Skill do mod dat */
    public final boolean canonDefault;

    DemonType(String title, String tag, Formatting color, boolean canonDefault) {
        this.title = title; this.tag = tag; this.color = color; this.canonDefault = canonDefault;
    }
}
